# Transfer Project to Personal PC

## Step 1: Copy Project Files

1. **On Work Laptop**: Copy the entire `AI Inventory` folder
   - Location: `c:\Users\KRA2665\AI Inventory`
   - Copy to USB drive or cloud storage (Google Drive, OneDrive, etc.)

2. **On Personal PC**: Paste the folder to a convenient location
   - Example: `C:\Users\[YourUsername]\Projects\AI Inventory`

## Step 2: Install Python & Tools

### Install Python 3.10+
1. Download from https://www.python.org/downloads/
2. Install with "Add Python to PATH" checked
3. Verify: Open PowerShell and run:
   ```powershell
   python --version
   ```

### Install Git (optional but recommended)
- Download from https://git-scm.com/download/win

### Install VS Code Extensions
- Python (ms-python.python)
- Pylance (ms-python.vscode-pylance)
- SQLTools (mtxr.sqltools)

## Step 3: Set Up Virtual Environment

```powershell
# Navigate to the project folder
cd "C:\Users\[YourUsername]\Projects\AI Inventory"

# Create virtual environment
python -m venv .venv

# Activate virtual environment
.\.venv\Scripts\Activate.ps1

# Install dependencies
pip install -r backend\requirements.txt
```

## Step 4: Configure Environment Variables

1. Create `.env` file in project root (copy from work laptop):
   ```
   DB_HOST=hca-inventory-db.cy38ska2yyb9.us-east-1.rds.amazonaws.com
   DB_USER=admin
   DB_PASSWORD=20032004Ayoob3
   DB_NAME=ai_inventory
   DB_PORT=3306
   FLASK_ENV=development
   JWT_SECRET=your-secret-key-12345
   ADMIN_USER=admin
   ADMIN_PASSWORD=admin
   ```

2. **IMPORTANT**: Once set up, add `.env` to `.gitignore` so passwords aren't committed

## Step 5: Set Up AWS Credentials (for Elastic Beanstalk Deployment)

Create `C:\Users\[YourUsername]\.aws\credentials` file with:
```
[default]
aws_access_key_id=YOUR_ACCESS_KEY
aws_secret_access_key=YOUR_SECRET_KEY
```

Create `C:\Users\[YourUsername]\.aws\config` file with:
```
[default]
region=us-east-1
```

**Get credentials from**: AWS Console → Security Credentials → Access Keys

## Step 6: Run Locally

### Terminal 1 - Backend (Flask)
```powershell
cd "C:\Users\[YourUsername]\Projects\AI Inventory\backend"
.\..\venv\Scripts\Activate.ps1
python run.py
```
Backend will run at: http://localhost:5000

### Terminal 2 - Frontend (React)
```powershell
cd "C:\Users\[YourUsername]\Projects\AI Inventory\frontend"
npm install
npm start
```
Frontend will run at: http://localhost:3000

## Step 7: Connect to Database

The app connects to the shared AWS RDS database:
- Host: `hca-inventory-db.cy38ska2yyb9.us-east-1.rds.amazonaws.com`
- User: `admin`
- Database: `ai_inventory`

### Test Connection
```powershell
# In VS Code terminal (backend folder activated)
python -c "from app import create_app; app = create_app(); from app import db; print('✓ Database connection successful')"
```

## Step 8: Test Health Endpoint

With backend running, in browser or PowerShell:
```powershell
curl http://localhost:5000/health
```

Should return: `{"status":"healthy"}`

## Step 9: Initialize Database (First Time Only)

```powershell
# Still in backend folder with venv activated
python -c "from app import create_app; from app import db; app = create_app(); app.app_context().push(); db.create_all(); print('✓ Database initialized')"
```

## Step 10: Deploy to Elastic Beanstalk (Optional)

When ready to deploy:

1. Install EB CLI:
   ```powershell
   pip install awsebcli
   ```

2. Deploy:
   ```powershell
   cd "C:\Users\[YourUsername]\Projects\AI Inventory"
   eb deploy
   ```

## Troubleshooting

### Port Already in Use
If port 5000 is busy:
```powershell
# Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Or change port in backend/run.py: PORT=5001
```

### Database Connection Failed
- Check `.env` file has correct credentials
- Verify AWS RDS is running: AWS Console → RDS → Databases
- Test from Command Line:
  ```powershell
  python -c "import pymysql; pymysql.connect(host='hca-inventory-db.cy38ska2yyb9.us-east-1.rds.amazonaws.com', user='admin', password='20032004Ayoob3', database='ai_inventory')"
  ```

### npm Install Fails
```powershell
# Clear npm cache
npm cache clean --force

# Try again
npm install
```

## File Structure

```
AI Inventory/
├── backend/
│   ├── app/
│   │   ├── __init__.py      (Flask factory)
│   │   ├── routes.py        (API endpoints)
│   │   ├── models.py        (Database models)
│   │   └── ai.py            (ML module)
│   ├── requirements.txt
│   ├── run.py               (Entry point)
│   ├── wsgi.py              (Gunicorn entry point)
│   └── Dockerfile
├── frontend/
│   ├── public/
│   ├── src/
│   ├── package.json
│   └── README.md
├── .env                      (Environment variables - don't commit!)
├── .elasticbeanstalk/
│   └── config.yml           (EB configuration)
└── Procfile
```

## Key Commands Reference

```powershell
# Activate environment
.\.venv\Scripts\Activate.ps1

# Run backend
python backend/run.py

# Run frontend
cd frontend && npm start

# Deploy to AWS
eb deploy

# Check EB status
eb status

# View EB logs
eb logs

# Run database CLI tool
python backend/cli.py
```

## Next Steps

1. ✅ Copy files to personal PC
2. ✅ Install Python and VS Code
3. ✅ Set up virtual environment
4. ✅ Configure `.env` file
5. ✅ Install dependencies
6. ✅ Run locally and test
7. ⏳ Deploy to Elastic Beanstalk when ready

**Questions?** Check the README.md in the project root for more details.
