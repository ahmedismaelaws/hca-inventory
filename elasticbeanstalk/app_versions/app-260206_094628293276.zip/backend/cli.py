import argparse
import os
import sys
from app import create_app, db
from app.models import Device
from app.ai import train_from_csv

def init_db():
    """Initialize database tables"""
    app = create_app()
    with app.app_context():
        try:
            db.create_all()
            print("✅ Database tables created successfully!")
            return True
        except Exception as e:
            print(f"❌ Error creating tables: {str(e)}")
            return False

def train_model(csv_path):
    """Train AI model from CSV"""
    path = os.path.abspath(csv_path)
    
    if not os.path.exists(path):
        print(f"❌ File not found: {path}")
        return False
    
    try:
        print(f"🧠 Training model from {path}...")
        dest = train_from_csv(path)
        print(f"✅ Model trained and saved to {dest}")
        return True
    except Exception as e:
        print(f"❌ Error training model: {str(e)}")
        return False

def main():
    parser = argparse.ArgumentParser(
        description='HCA IT Inventory Management - CLI Tools',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python cli.py --init-db
  python cli.py --train-csv sample_data/sample_devices.csv
        """
    )
    
    parser.add_argument('--init-db', 
                        action='store_true',
                        help='Initialize database tables')
    
    parser.add_argument('--train-csv', 
                        metavar='PATH',
                        help='Train AI model from CSV file')
    
    args = parser.parse_args()
    
    if args.init_db:
        print("🔧 Initializing database...")
        success = init_db()
        sys.exit(0 if success else 1)
    
    elif args.train_csv:
        print("🤖 Training AI model...")
        success = train_model(args.train_csv)
        sys.exit(0 if success else 1)
    
    else:
        parser.print_help()
        sys.exit(0)

if __name__ == '__main__':
    main()
