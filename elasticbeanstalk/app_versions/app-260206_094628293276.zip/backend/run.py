"""
HCA IT Inventory Management System - Backend Server
Flask application entry point
"""
import os
import logging
import sys

# Configure logging BEFORE importing app
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stdout,
    force=True
)
logger = logging.getLogger(__name__)

logger.info("=" * 60)
logger.info("Starting HCA IT Inventory Backend")
logger.info("=" * 60)

try:
    logger.info("Importing Flask app factory...")
    from app import create_app
    logger.info("✓ App factory imported successfully")
    
    logger.info("Creating Flask application...")
    app = create_app()
    logger.info("✓ Flask application created successfully")
    
except ImportError as e:
    logger.error(f"❌ Import error: {str(e)}")
    logger.error(f"This is likely a missing dependency. Check requirements.txt")
    raise
except Exception as e:
    logger.error(f"❌ Failed to create app: {str(e)}")
    import traceback
    logger.error(traceback.format_exc())
    raise

logger.info("=" * 60)
logger.info("Application ready for requests")
logger.info("=" * 60)

if __name__ == '__main__':
    try:
        port = int(os.environ.get('PORT', 5000))
        debug = os.environ.get('FLASK_ENV', 'production') == 'development'
        
        logger.info(f"Starting server on port {port} (debug={debug})")
        logger.info(f"Binding to 0.0.0.0:{port}")
        
        # Start Flask development server (Elastic Beanstalk/Docker will handle this)
        app.run(
            host='0.0.0.0',
            port=port,
            debug=debug,
            use_reloader=False,  # Disable in containers
            threaded=True  # Enable threading for concurrent requests
        )
    except KeyboardInterrupt:
        logger.info("Server interrupted")
        sys.exit(0)
    except Exception as e:
        logger.error(f"❌ Failed to start app: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        sys.exit(1)

logger.info("✓ run.py module loaded successfully")

