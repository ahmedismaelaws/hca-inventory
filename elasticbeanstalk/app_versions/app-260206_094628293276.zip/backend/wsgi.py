"""
WSGI entry point for Gunicorn
This file is used by Elastic Beanstalk to start the Flask application
"""
import os
import sys
import logging

# Configure logging FIRST
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stdout,
    force=True
)
logger = logging.getLogger(__name__)

# Ensure we can import the app module from current directory
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

logger.info("=" * 70)
logger.info("WSGI STARTUP")
logger.info("=" * 70)
logger.info(f"Working directory: {current_dir}")
logger.info(f"Python path: {sys.path[:3]}")

try:
    logger.info("Importing Flask app factory...")
    from app import create_app
    logger.info("✓ App factory imported")
    
    logger.info("Creating Flask application...")
    app = create_app()
    logger.info("✓ Flask application created successfully")
    logger.info("=" * 70)
    
except ImportError as e:
    logger.error(f"❌ Import Error: {str(e)}")
    logger.error("Failed to import app module. Check that app/ directory exists with __init__.py")
    import traceback
    logger.error(traceback.format_exc())
    raise
    
except Exception as e:
    logger.error(f"❌ Failed to create app: {str(e)}")
    import traceback
    logger.error(traceback.format_exc())
    raise

# This is the app object that Gunicorn will use

# Gunicorn expects: gunicorn -b 0.0.0.0:5000 wsgi:app
