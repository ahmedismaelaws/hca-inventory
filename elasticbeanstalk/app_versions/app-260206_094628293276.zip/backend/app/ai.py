import os
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from typing import Optional

MODEL_PATH = os.path.join(os.path.dirname(__file__), '..', 'models', 'ai_model.joblib')


def train_from_csv(csv_path: str, save_path: Optional[str] = None):
    df = pd.read_csv(csv_path)
    if 'description' not in df.columns or 'category' not in df.columns:
        raise ValueError("CSV must have 'description' and 'category' columns")
    X = df['description'].fillna('')
    y = df['category'].fillna('')

    pipe = Pipeline([
        ('tfidf', TfidfVectorizer(ngram_range=(1,2), max_features=4000)),
        ('clf', LogisticRegression(max_iter=1000))
    ])
    pipe.fit(X, y)

    os.makedirs(os.path.join(os.path.dirname(__file__), '..', 'models'), exist_ok=True)
    dest = save_path or MODEL_PATH
    joblib.dump(pipe, dest)
    return dest


def load_model():
    if not os.path.exists(MODEL_PATH):
        return None
    return joblib.load(MODEL_PATH)


def suggest_category(description: str):
    model = load_model()
    if model is None:
        return None
    pred = model.predict([description])
    return pred[0]
