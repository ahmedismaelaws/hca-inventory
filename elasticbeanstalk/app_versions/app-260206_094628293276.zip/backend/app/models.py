from . import db
from datetime import datetime


class Device(db.Model):
    """
    Device Model - Represents IT equipment in the inventory
    
    Attributes:
        id: Unique identifier (auto-increment)
        name: Device name/model (required)
        description: Detailed description of the device
        category: Device category (e.g., Laptop, Server, Printer)
        location: Physical location of the device
        created_at: Timestamp when device was added
    """
    
    __tablename__ = 'devices'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False, index=True)
    description = db.Column(db.Text, nullable=True)
    category = db.Column(db.String(128), nullable=True, index=True)
    location = db.Column(db.String(255), nullable=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    
    def __repr__(self):
        """String representation of Device"""
        return f'<Device {self.id}: {self.name}>'
    
    def to_dict(self):
        """Convert device to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'category': self.category,
            'location': self.location,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }
    
    @staticmethod
    def from_dict(data):
        """Create Device instance from dictionary"""
        return Device(
            name=data.get('name', '').strip(),
            description=data.get('description', '').strip(),
            category=data.get('category', '').strip(),
            location=data.get('location', '').strip()
        )
