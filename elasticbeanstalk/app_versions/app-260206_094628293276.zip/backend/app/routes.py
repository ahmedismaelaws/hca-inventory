from flask import Blueprint, request, jsonify, current_app
from . import db
from .models import Device
from flask_jwt_extended import create_access_token, jwt_required
from sqlalchemy.exc import IntegrityError
import os
import logging

# Configure logging
logger = logging.getLogger(__name__)

# Import AI module safely - it's optional
try:
    from .ai import suggest_category
    ai_available = True
except Exception as e:
    logger.warning(f"AI module not available: {e}")
    ai_available = False
    suggest_category = None

bp = Blueprint('api', __name__)


def validate_device_data(data, is_update=False):
    """Validate device data before database operations"""
    errors = []
    
    if not is_update:  # Create requires name
        if not data.get('name') or not str(data.get('name')).strip():
            errors.append('Device name is required')
    
    name = data.get('name', '').strip() if data.get('name') else ''
    if name and len(name) > 255:
        errors.append('Device name must be 255 characters or less')
    
    if data.get('category') and len(str(data.get('category'))) > 128:
        errors.append('Category must be 128 characters or less')
    
    if data.get('location') and len(str(data.get('location'))) > 255:
        errors.append('Location must be 255 characters or less')
    
    return errors


@bp.route('/auth/login', methods=['POST'])
def login():
    """Authenticate user and return JWT token"""
    try:
        data = request.json or {}
        username = data.get('username', '').strip()
        password = data.get('password', '')
        
        if not username or not password:
            return jsonify({'msg': 'Username and password required'}), 400
        
        admin_user = os.environ.get('ADMIN_USER', 'admin')
        admin_pass = os.environ.get('ADMIN_PASSWORD', 'admin')
        
        if username == admin_user and password == admin_pass:
            token = create_access_token(identity={'username': admin_user})
            return jsonify({'access_token': token}), 200
        
        return jsonify({'msg': 'Invalid credentials'}), 401
    except Exception as e:
        logger.error(f"Login error: {str(e)}")
        return jsonify({'msg': 'An error occurred during login'}), 500


@bp.route('/auth/validate', methods=['GET'])
@jwt_required()
def validate_token():
    """Validate JWT token"""
    return jsonify({'valid': True}), 200


@bp.route('/devices', methods=['GET'])
@jwt_required(optional=True)
def list_devices():
    """Get all devices with optional pagination and filtering"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 100, type=int)
        search = request.args.get('search', '', type=str).lower()
        category = request.args.get('category', '', type=str)
        
        per_page = min(per_page, 100)  # Limit to 100 items per page
        
        query = Device.query.order_by(Device.id.desc())
        
        if search:
            query = query.filter(
                (Device.name.ilike(f'%{search}%')) |
                (Device.description.ilike(f'%{search}%')) |
                (Device.location.ilike(f'%{search}%'))
            )
        
        if category:
            query = query.filter(Device.category == category)
        
        devices = query.paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'items': [d.to_dict() for d in devices.items],
            'total': devices.total,
            'pages': devices.pages,
            'current_page': page
        }), 200
    except Exception as e:
        logger.error(f"List devices error: {str(e)}")
        return jsonify({'msg': 'Failed to retrieve devices'}), 500


@bp.route('/devices/<int:device_id>', methods=['GET'])
@jwt_required(optional=True)
def get_device(device_id):
    """Get a specific device by ID"""
    try:
        device = Device.query.get(device_id)
        if not device:
            return jsonify({'msg': 'Device not found'}), 404
        return jsonify(device.to_dict()), 200
    except Exception as e:
        logger.error(f"Get device error: {str(e)}")
        return jsonify({'msg': 'Failed to retrieve device'}), 500


@bp.route('/devices', methods=['POST'])
@jwt_required()
def create_device():
    """Create a new device"""
    try:
        if not request.json:
            return jsonify({'msg': 'Request body required'}), 400
        
        data = request.json
        validation_errors = validate_device_data(data, is_update=False)
        
        if validation_errors:
            return jsonify({'msg': 'Validation error', 'errors': validation_errors}), 400
        
        device = Device(
            name=data.get('name', '').strip(),
            description=data.get('description', '').strip(),
            category=data.get('category', '').strip(),
            location=data.get('location', '').strip()
        )
        
        db.session.add(device)
        db.session.commit()
        
        logger.info(f"Device created: {device.id}")
        return jsonify(device.to_dict()), 201
    except IntegrityError as e:
        db.session.rollback()
        logger.error(f"Database integrity error: {str(e)}")
        return jsonify({'msg': 'Device data conflict'}), 409
    except Exception as e:
        db.session.rollback()
        logger.error(f"Create device error: {str(e)}")
        return jsonify({'msg': 'Failed to create device'}), 500


@bp.route('/devices/<int:device_id>', methods=['PUT'])
@jwt_required()
def update_device(device_id):
    """Update an existing device"""
    try:
        device = Device.query.get(device_id)
        if not device:
            return jsonify({'msg': 'Device not found'}), 404
        
        if not request.json:
            return jsonify({'msg': 'Request body required'}), 400
        
        data = request.json
        validation_errors = validate_device_data(data, is_update=True)
        
        if validation_errors:
            return jsonify({'msg': 'Validation error', 'errors': validation_errors}), 400
        
        if 'name' in data and data['name']:
            device.name = data['name'].strip()
        if 'description' in data:
            device.description = data['description'].strip()
        if 'category' in data:
            device.category = data['category'].strip()
        if 'location' in data:
            device.location = data['location'].strip()
        
        db.session.commit()
        logger.info(f"Device updated: {device_id}")
        return jsonify(device.to_dict()), 200
    except IntegrityError as e:
        db.session.rollback()
        logger.error(f"Database integrity error: {str(e)}")
        return jsonify({'msg': 'Device data conflict'}), 409
    except Exception as e:
        db.session.rollback()
        logger.error(f"Update device error: {str(e)}")
        return jsonify({'msg': 'Failed to update device'}), 500


@bp.route('/devices/<int:device_id>', methods=['DELETE'])
@jwt_required()
def delete_device(device_id):
    """Delete a device"""
    try:
        device = Device.query.get(device_id)
        if not device:
            return jsonify({'msg': 'Device not found'}), 404
        
        db.session.delete(device)
        db.session.commit()
        logger.info(f"Device deleted: {device_id}")
        return jsonify({'msg': 'Device deleted successfully'}), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f"Delete device error: {str(e)}")
        return jsonify({'msg': 'Failed to delete device'}), 500


@bp.route('/devices/import', methods=['POST'])
@jwt_required()
def import_csv():
    """Import devices from CSV file"""
    try:
        if 'file' not in request.files:
            return jsonify({'msg': 'File is required'}), 400
        
        file = request.files['file']
        
        if not file or file.filename == '':
            return jsonify({'msg': 'No file selected'}), 400
        
        if not file.filename.lower().endswith('.csv'):
            return jsonify({'msg': 'Only CSV files are allowed'}), 400
        
        try:
            import pandas as pd
            df = pd.read_csv(file)
        except Exception as e:
            logger.error(f"CSV parse error: {str(e)}")
            return jsonify({'msg': 'Invalid CSV format'}), 400
        
        if df.empty:
            return jsonify({'msg': 'CSV file is empty'}), 400
        
        created = 0
        skipped = 0
        
        for idx, row in df.iterrows():
            try:
                name = str(row.get('name') or row.get('device') or '').strip()
                if not name:
                    skipped += 1
                    continue
                
                device = Device(
                    name=name[:255],
                    description=str(row.get('description', '')).strip()[:1000],
                    category=str(row.get('category', '')).strip()[:128],
                    location=str(row.get('location', '')).strip()[:255]
                )
                db.session.add(device)
                created += 1
            except Exception as e:
                logger.warning(f"Skipping row {idx}: {str(e)}")
                skipped += 1
                continue
        
        db.session.commit()
        logger.info(f"CSV import complete: {created} created, {skipped} skipped")
        return jsonify({'created': created, 'skipped': skipped}), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f"CSV import error: {str(e)}")
        return jsonify({'msg': 'Failed to import CSV'}), 500


@bp.route('/ai/suggest', methods=['POST'])
@jwt_required(optional=True)
def ai_suggest():
    """Suggest device category using AI"""
    try:
        data = request.json or {}
        description = data.get('description', '').strip()
        
        if not description:
            return jsonify({'msg': 'Description is required for suggestions'}), 400
        
        if len(description) < 10:
            return jsonify({'msg': 'Description too short for accurate suggestion'}), 400
        
        if not ai_available or suggest_category is None:
            return jsonify({'msg': 'AI module not available'}), 503
        
        suggestion = suggest_category(description)
        
        if suggestion is None:
            return jsonify({'msg': 'AI model not trained. Please train the model first.'}), 503
        
        return jsonify({'suggested_category': suggestion}), 200
    except Exception as e:
        logger.error(f"AI suggest error: {str(e)}")
        return jsonify({'msg': 'Failed to generate suggestion'}), 500


@bp.route('/categories', methods=['GET'])
@jwt_required(optional=True)
def list_categories():
    """Get list of all unique device categories"""
    try:
        categories = db.session.query(Device.category).distinct().filter(
            Device.category != None, Device.category != ''
        ).all()
        category_list = sorted([c[0] for c in categories if c[0]])
        return jsonify({'categories': category_list}), 200
    except Exception as e:
        logger.error(f"List categories error: {str(e)}")
        return jsonify({'msg': 'Failed to retrieve categories'}), 500


@bp.route('/stats', methods=['GET'])
@jwt_required(optional=True)
def get_stats():
    """Get inventory statistics"""
    try:
        total_devices = Device.query.count()
        categories = db.session.query(Device.category).distinct().count()
        locations = db.session.query(Device.location).distinct().count()
        
        return jsonify({
            'total_devices': total_devices,
            'unique_categories': categories,
            'unique_locations': locations
        }), 200
    except Exception as e:
        logger.error(f"Get stats error: {str(e)}")
        return jsonify({'msg': 'Failed to retrieve statistics'}), 500


@bp.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({'msg': 'Resource not found'}), 404


@bp.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    logger.error(f"Internal server error: {str(error)}")
    return jsonify({'msg': 'Internal server error'}), 500
