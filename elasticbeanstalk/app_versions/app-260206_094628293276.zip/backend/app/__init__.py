import os
import logging
import sys
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from dotenv import load_dotenv

# Try to load .env if it exists (useful for local development)
# In production (Elastic Beanstalk), environment variables are set via .ebextensions
try:
    load_dotenv()
except Exception as e:
    pass  # .env might not exist in Docker, that's OK

logger = logging.getLogger(__name__)

db = SQLAlchemy()
migrate = Migrate()
jwt = JWTManager()


def create_app():
    app = Flask(__name__)
    
    # Log configuration for debugging
    logger.info("=" * 70)
    logger.info("CREATING FLASK APPLICATION")
    logger.info("=" * 70)
    logger.info(f"DB_HOST: {os.environ.get('DB_HOST', 'NOT SET')}")
    logger.info(f"DB_USER: {os.environ.get('DB_USER', 'NOT SET')}")
    logger.info(f"DB_NAME: {os.environ.get('DB_NAME', 'NOT SET')}")
    logger.info(f"FLASK_ENV: {os.environ.get('FLASK_ENV', 'NOT SET')}")
    
    # Configuration
    db_user = os.environ.get('DB_USER', 'aiuser')
    db_password = os.environ.get('DB_PASSWORD', 'ai_password')
    db_host = os.environ.get('DB_HOST', 'localhost')
    db_port = os.environ.get('DB_PORT', 3306)
    db_name = os.environ.get('DB_NAME', 'ai_inventory')
    
    database_uri = f"mysql+pymysql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
    logger.info(f"Database URI: mysql+pymysql://{db_user}:***@{db_host}:{db_port}/{db_name}")
    
    app.config['SQLALCHEMY_DATABASE_URI'] = database_uri
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
        'connect_args': {'check_same_thread': False},
        'pool_pre_ping': True,
        'pool_recycle': 3600,
    }
    app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET','dev-secret-change-in-production')
    app.config['JSON_SORT_KEYS'] = False
    
    logger.info("Initializing CORS...")
    # Enable CORS
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    
    logger.info("Initializing database extensions...")
    # Initialize extensions
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    
    logger.info("✓ All extensions initialized successfully")
    logger.info("=" * 70)
    
    # Health check endpoint (doesn't require DB)
    @app.route('/health', methods=['GET'])
    def health():
        return {'status': 'healthy'}, 200
    
    @app.route('/', methods=['GET'])
    def root():
        return {'message': 'HCA IT Inventory API is running'}, 200
    
    @app.route('/init-db', methods=['POST', 'GET'])
    def init_database():
        """Initialize database tables - for first-time setup"""
        try:
            with app.app_context():
                db.create_all()
            return {'status': 'success', 'message': 'Database tables initialized'}, 200
        except Exception as e:
            return {'status': 'error', 'message': str(e)}, 500
    
    # Register blueprints - don't fail if routes have issues
    try:
        from .routes import bp as api_bp
        app.register_blueprint(api_bp, url_prefix='/api')
        logger.info("✅ API routes registered successfully")
    except Exception as e:
        logger.warning(f"⚠️ Could not register API routes (DB may not be ready): {str(e)}")
        # App will still work for health checks and init-db
        # Define a fallback API status endpoint
        @app.route('/api/status', methods=['GET'])
        def api_status():
            return {'status': 'initializing', 'message': 'Database not yet initialized. Call /init-db'}, 200
    
    # Error handlers
    @app.errorhandler(400)
    def bad_request(error):
        return {'msg': 'Bad request'}, 400
    
    @app.errorhandler(404)
    def not_found(error):
        return {'msg': 'Not found'}, 404
    
    @app.errorhandler(500)
    def internal_error(error):
        return {'msg': 'Internal server error'}, 500
    
    return app
