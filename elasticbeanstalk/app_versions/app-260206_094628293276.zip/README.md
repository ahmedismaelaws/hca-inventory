# 🏥 HCA IT Department Inventory Management System

A professional, full-stack web application for managing IT Department equipment and inventory. Built with React, Flask, MySQL, and AI-powered category suggestions.

## ✨ Features

- **✅ Complete Inventory Management**: Add, edit, delete, view IT equipment
- **🔍 Advanced Search & Filtering**: Filter by name, description, location, category
- **🤖 AI-Powered Suggestions**: Automatic device category suggestions using ML
- **🔐 Secure Authentication**: JWT-based user authentication
- **📱 Responsive Design**: Works on desktop, tablet, and mobile devices
- **📤 CSV Import**: Bulk import devices from spreadsheets
- **📊 Statistics Dashboard**: View inventory summaries
- **🏷️ Category Management**: Organize equipment efficiently
- **📍 Location Tracking**: Track devices across the organization

## 🚀 Quick Start

### Prerequisites
- **Docker & Docker Compose** (recommended)
- OR: Python 3.10+, Node.js 16+, MySQL 8.0

### Using Docker (Recommended)

```powershell
# Navigate to project
cd "c:\Users\KRA2665\AI Inventory"

# Start all services
docker-compose up --build -d

# Wait for MySQL to be ready, then initialize
Start-Sleep -Seconds 10
docker-compose exec backend python cli.py --init-db

# Train AI model (optional but recommended)
docker-compose exec backend python cli.py --train-csv /app/sample_data/sample_devices.csv
```

**Access the application:**
- Frontend: http://localhost:3000
- API: http://localhost:5000/api
- **Login**: admin / admin

### Local Development

**Backend:**
```powershell
cd backend
python -m venv venv
.\venv\Scripts\activate
pip install -r requirements.txt
$env:FLASK_APP = "run.py"
$env:FLASK_ENV = "development"
python cli.py --init-db
python run.py
```

**Frontend (new terminal):**
```powershell
cd frontend
npm install
npm start
```

## 🏗️ Architecture

```
HCA Inventory System
├── Backend (Flask + MySQL)
│   ├── JWT Authentication
│   ├── REST API
│   ├── Database Models
│   └── AI/ML Module
├── Frontend (React)
│   ├── Responsive UI
│   ├── Real-time Search
│   └── Device Management
└── Database
    └── MySQL 8.0
```

## 📚 API Endpoints

### Authentication
- `POST /api/auth/login` - Login and get JWT token
- `GET /api/auth/validate` - Validate token

### Devices
- `GET /api/devices` - List all devices (with pagination)
- `GET /api/devices/{id}` - Get device details
- `POST /api/devices` - Create new device (auth required)
- `PUT /api/devices/{id}` - Update device (auth required)
- `DELETE /api/devices/{id}` - Delete device (auth required)
- `POST /api/devices/import` - Bulk import from CSV (auth required)

### AI & Utilities
- `POST /api/ai/suggest` - Get category suggestion for description
- `GET /api/categories` - List all device categories
- `GET /api/stats` - Get inventory statistics

## 🔐 Security Features

✅ JWT Token Authentication  
✅ CORS Enabled (configurable)  
✅ Input Validation & Sanitization  
✅ SQL Injection Prevention (SQLAlchemy ORM)  
✅ Environment Variable Protection  
✅ Error Handling  

## 📊 CSV Import Format

```csv
name,description,category,location
Dell XPS 13,Laptop for development,Laptop,Office 101
HP LaserJet,Office printer,Printer,Break Room
Dell Server,Production database server,Server,Server Room
```

## 📦 Tech Stack

**Backend:**
- Flask 2.3.3
- SQLAlchemy 2.0
- MySQL 8.0
- scikit-learn (ML)
- JWT-Extended

**Frontend:**
- React 18.2
- Axios (HTTP)
- CSS3 (Responsive Design)
- Create React App

**DevOps:**
- Docker
- Docker Compose
- Flask-Migrate

## 🧠 AI Model Training

```bash
# Train using sample data
docker-compose exec backend python cli.py --train-csv /app/sample_data/sample_devices.csv

# Or with your own CSV
docker-compose exec backend python cli.py --train-csv /path/to/your/data.csv
```

Model: TF-IDF + Logistic Regression (scikit-learn)

## 🐛 Troubleshooting

```bash
# View logs
docker-compose logs -f backend

# Check service status
docker-compose ps

# Restart everything
docker-compose down
docker-compose up --build -d

# MySQL connection
# Host: 127.0.0.1, Port: 3306
# User: aiuser, Password: ai_password
```

## 📋 Environment Variables

Copy `.env.example` to `.env` and customize:

```
DB_HOST=mysql
DB_PORT=3306
DB_USER=aiuser
DB_PASSWORD=ai_password
DB_NAME=ai_inventory
JWT_SECRET=your-secret-key
ADMIN_USER=admin
ADMIN_PASSWORD=admin
```

## 📈 Database Connection with MySQL Workbench

1. Host: 127.0.0.1
2. Port: 3306
3. Username: aiuser
4. Password: ai_password
5. Database: ai_inventory

## ✅ Production Checklist

- [ ] Change ADMIN_PASSWORD in .env
- [ ] Generate strong JWT_SECRET: `python -c "import secrets; print(secrets.token_urlsafe(32))"`
- [ ] Use strong MySQL password
- [ ] Enable HTTPS
- [ ] Set up backups
- [ ] Monitor logs
- [ ] Configure firewall rules

## 🎓 Capstone Project Features

✅ Full CRUD Operations  
✅ Authentication & Authorization  
✅ AI/ML Integration  
✅ Responsive Frontend  
✅ Database Design  
✅ Error Handling  
✅ Documentation  
✅ Docker Containerization  
✅ Production-Ready Code  
✅ User-Friendly UI  

## 📞 Support

For issues:
1. Check `docker-compose logs`
2. Verify MySQL connection
3. Check environment variables
4. Review API responses

---

**Version**: 1.0.0  
**Status**: ✅ Production Ready  
**Last Updated**: 2026-02-05
