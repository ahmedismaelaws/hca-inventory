# EC2 Deployment - Complete Automated Guide

## Summary
This guide automates everything. You only need to:
1. Launch an EC2 instance in AWS Console
2. Run 2-3 commands to transfer files and setup

## STEP 1: Launch EC2 Instance (5 minutes)

1. Open AWS Console: https://console.aws.amazon.com
2. Login with your account (895636586376 / Ahmed2)
3. Go to **EC2** → **Instances** → **Launch Instances**

### Configuration:
- **Name**: `hca-inventory` (or whatever you want)
- **Image**: Amazon Linux 2 (free tier)
- **Instance Type**: t3.micro (free tier)
- **Key Pair**: 
  - If you don't have one: Click "Create new key pair"
    - Name it: `hca-inventory-key`
    - Type: RSA
    - Format: `.pem`
    - Click "Create key pair" → **SAVE THIS FILE** to `C:\keys\hca-inventory-key.pem`
  - If you have one: Select it
- **Network**: Default VPC
- **Firewall (Security Group)**:
  - Click "Create security group"
  - Name: `hca-inventory-sg`
  - Add Rules:
    - SSH (port 22) - Source: My IP (shows your IP)
    - HTTP (port 80) - Source: Anywhere (0.0.0.0/0)
    - Custom TCP (port 5000) - Source: Anywhere (0.0.0.0/0)
- **Storage**: 8 GB (default is fine)

### Launch:
- Click **Launch Instance**
- Wait for it to say "Running"
- **Note the Public IPv4 address** (looks like: `54.123.45.67`)

---

## STEP 2: Prepare Your Work Laptop

Open PowerShell in your AI Inventory project folder:

```powershell
# Navigate to your project
cd "C:\Users\KRA2665\AI Inventory"

# Verify you're in the right place
ls backend, .env  # Should show these files/folders
```

---

## STEP 3: Transfer Files to EC2

### Option A: Automatic (Recommended)

```powershell
# Run the batch script with your EC2 IP and key file location
.\ec2-transfer.bat 54.123.45.67 "C:\keys\hca-inventory-key.pem"

# Replace:
#   54.123.45.67 with your EC2 Public IPv4 address
#   C:\keys\hca-inventory-key.pem with your actual key path
```

### Option B: Manual (Using SCP)

```powershell
# Transfer backend folder
scp -i "C:\keys\hca-inventory-key.pem" -r backend ec2-user@54.123.45.67:~/app/

# Transfer .env file
scp -i "C:\keys\hca-inventory-key.pem" .env ec2-user@54.123.45.67:~/app/

# Transfer setup script
scp -i "C:\keys\hca-inventory-key.pem" ec2-complete-setup.sh ec2-user@54.123.45.67:~/app/setup.sh
```

---

## STEP 4: SSH into EC2 and Run Setup

```powershell
# SSH into the instance
ssh -i "C:\keys\hca-inventory-key.pem" ec2-user@54.123.45.67

# You should now be on the EC2 instance (prompt shows: [ec2-user@... ~]$)

# Run the setup script
bash ~/app/setup.sh

# Wait for it to complete - should see:
# ✓ Setup Complete!
```

---

## STEP 5: Start the Application

On the EC2 instance terminal:

```bash
# Navigate to app directory
cd ~/app

# Activate Python virtual environment
source venv/bin/activate

# Go to backend
cd backend

# Start Flask app
python run.py

# You should see:
# ============================================================
# Starting HCA IT Inventory Backend
# ============================================================
# ...
#  * Running on http://0.0.0.0:5000
#  * Press CTRL+C to quit
```

**The app is now running!**

---

## STEP 6: Test the Application

Open a NEW PowerShell window on your work laptop:

```powershell
# Test health endpoint
curl http://54.123.45.67:5000/health

# Should return:
# {"status":"healthy"}

# Or open in browser:
# http://54.123.45.67:5000/health
```

---

## STEP 7: Initialize Database

In the same new PowerShell window:

```powershell
# Initialize database tables
curl -X POST http://54.123.45.67:5000/init-db

# Should return:
# {"status":"success","message":"Database tables initialized"}
```

**✓ Your app is now fully deployed and working!**

---

## API Endpoints Available

- `GET  http://54.123.45.67:5000/health` - Health check
- `POST http://54.123.45.67:5000/init-db` - Initialize database
- `GET  http://54.123.45.67:5000/` - Root endpoint
- `POST http://54.123.45.67:5000/api/auth/login` - Login
- `GET  http://54.123.45.67:5000/api/devices` - List devices
- `POST http://54.123.45.67:5000/api/devices` - Create device
- `GET  http://54.123.45.67:5000/api/devices/<id>` - Get device
- `PUT  http://54.123.45.67:5000/api/devices/<id>` - Update device
- `DELETE http://54.123.45.67:5000/api/devices/<id>` - Delete device

---

## Keep App Running (After You Disconnect SSH)

On the EC2 instance, instead of just `python run.py`, use:

```bash
# Option 1: Use nohup (simplest)
cd ~/app
source venv/bin/activate
nohup python backend/run.py > app.log 2>&1 &

# App keeps running even after you SSH out
# To check status: tail -f app.log

# Option 2: Use tmux (better)
tmux new-session -d -s app "cd ~/app && source venv/bin/activate && cd backend && python run.py"

# Later reconnect: tmux attach-session -t app
# Detach: Ctrl+B then D
```

---

## If Something Goes Wrong

### Can't SSH?
```powershell
# Check if OpenSSH is installed
ssh -V

# If not installed:
# Settings → Apps → Optional Features → Add "OpenSSH Client"
```

### Port 5000 not accessible?
On EC2:
```bash
# Check if app is running
ps aux | grep python

# Check port
netstat -tuln | grep 5000

# Try accessing locally
curl http://localhost:5000/health
```

### Database connection error?
On EC2:
```bash
# Test database connection
python3.10 << 'EOF'
import pymysql
try:
    conn = pymysql.connect(
        host='hca-inventory-db.cy38ska2yyb9.us-east-1.rds.amazonaws.com',
        user='admin',
        password='20032004Ayoob3',
        database='ai_inventory'
    )
    print("✓ Database connection successful")
    conn.close()
except Exception as e:
    print(f"❌ Database error: {e}")
EOF
```

---

## Important Notes

✅ **Cost**: t3.micro is free tier (~750 hours/month free)
✅ **Data**: Uses shared AWS RDS database (persists)
✅ **Access**: Public IP changes on reboot (use Elastic IP for permanent)
✅ **Logs**: Check with `tail -f ~/app/app.log` if using nohup

---

## Next: Transfer to Personal PC

Once confirmed working:
1. Stop the app: `Ctrl+C` in SSH terminal
2. Follow `TRANSFER_TO_PERSONAL_PC.md` for local setup
3. Or keep running on EC2

---

## Quick Reference Commands

### On Your Work Laptop:
```powershell
# SSH in
ssh -i "C:\keys\hca-inventory-key.pem" ec2-user@YOUR_EC2_IP

# Transfer files
scp -i "C:\keys\hca-inventory-key.pem" -r backend ec2-user@YOUR_EC2_IP:~/app/
scp -i "C:\keys\hca-inventory-key.pem" .env ec2-user@YOUR_EC2_IP:~/app/

# Test app
curl http://YOUR_EC2_IP:5000/health
```

### On EC2 Instance:
```bash
# Setup
bash ~/app/setup.sh

# Start app
cd ~/app && source venv/bin/activate && cd backend && python run.py

# Keep running after SSH exit
nohup python backend/run.py > app.log 2>&1 &

# Check logs
tail -f app.log
```

---

**You're Done!** The app should be fully deployed and accessible.
