#!/usr/bin/env powershell
# Master Deployment Script - Does Everything Automatically
# Usage: .\deploy-master.ps1 -KeyPath "C:\path\to\key.pem" -EC2IP "3.226.255.34"

param(
    [string]$KeyPath,
    [string]$EC2IP = "3.226.255.34"
)

# If KeyPath not provided, ask for it
if (-not $KeyPath) {
    Write-Host ""
    Write-Host "=========================================" -ForegroundColor Green
    Write-Host "MASTER DEPLOYMENT SCRIPT" -ForegroundColor Green
    Write-Host "=========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Enter the full path to your SSH key (.pem file):" -ForegroundColor Cyan
    Write-Host "Example: C:\Users\YourName\Downloads\hca-inventory-key.pem" -ForegroundColor DarkGray
    $KeyPath = Read-Host "Key path"
}

# Validate key file exists
if (-not (Test-Path $KeyPath)) {
    Write-Host ""
    Write-Host "ERROR: Key file not found at: $KeyPath" -ForegroundColor Red
    Write-Host "Please provide the correct path to your .pem key file" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "=========================================" -ForegroundColor Green
Write-Host "AUTOMATIC DEPLOYMENT IN PROGRESS" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Green
Write-Host ""
Write-Host "EC2 IP: $EC2IP" -ForegroundColor Cyan
Write-Host "Key: $KeyPath" -ForegroundColor Cyan
Write-Host ""

# Step 1: Transfer Files
Write-Host "STEP 1: Transferring code files to EC2..." -ForegroundColor Yellow

try {
    ssh -i "$KeyPath" -o StrictHostKeyChecking=no ec2-user@$EC2IP "mkdir -p ~/app" 2>$null
    scp -i "$KeyPath" -o StrictHostKeyChecking=no -r "backend\*" ec2-user@${EC2IP}:~/app/backend/ 2>$null
    Write-Host "  OK: Backend transferred" -ForegroundColor Green
    
    scp -i "$KeyPath" -o StrictHostKeyChecking=no ".env" ec2-user@${EC2IP}:~/app/.env 2>$null
    Write-Host "  OK: .env transferred" -ForegroundColor Green
    
    scp -i "$KeyPath" -o StrictHostKeyChecking=no "ec2-complete-setup.sh" ec2-user@${EC2IP}:~/app/setup.sh 2>$null
    Write-Host "  OK: Setup script transferred" -ForegroundColor Green
}
catch {
    Write-Host "ERROR: Transfer failed: $_" -ForegroundColor Red
    exit 1
}

# Step 2: Run setup on EC2
Write-Host ""
Write-Host "STEP 2: Running setup on EC2..." -ForegroundColor Yellow

try {
    ssh -i "$KeyPath" -o StrictHostKeyChecking=no ec2-user@$EC2IP "bash ~/app/setup.sh" 2>&1
    Write-Host "  OK: Setup completed" -ForegroundColor Green
}
catch {
    Write-Host "WARNING: Setup output shown above" -ForegroundColor Yellow
}

# Step 3: Start Flask app
Write-Host ""
Write-Host "STEP 3: Starting Flask application..." -ForegroundColor Yellow

try {
    ssh -i "$KeyPath" -o StrictHostKeyChecking=no ec2-user@$EC2IP "cd ~/app && source venv/bin/activate && nohup python backend/run.py > ~/app/app.log 2>&1 &" 2>&1
    Write-Host "  OK: Application started" -ForegroundColor Green
    Write-Host "  Waiting for app to initialize..." -ForegroundColor DarkGray
    Start-Sleep -Seconds 5
}
catch {
    Write-Host "WARNING: Could not start app" -ForegroundColor Yellow
}

# Step 4: Test endpoints
Write-Host ""
Write-Host "STEP 4: Testing endpoints..." -ForegroundColor Yellow

$tests = @(
    @{ Name = "Health Check"; URL = "http://$EC2IP:5000/health" },
    @{ Name = "Root Endpoint"; URL = "http://$EC2IP:5000/" },
    @{ Name = "API Status"; URL = "http://$EC2IP:5000/api/status" }
)

foreach ($test in $tests) {
    try {
        $response = Invoke-WebRequest -Uri $test.URL -Method Get -TimeoutSec 5 -ErrorAction Stop
        if ($response.StatusCode -eq 200) {
            Write-Host "  OK: $($test.Name)" -ForegroundColor Green
        }
        else {
            Write-Host "  STATUS $($response.StatusCode): $($test.Name)" -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host "  WAIT: $($test.Name) - app still starting..." -ForegroundColor DarkGray
    }
}

# Step 5: Initialize database
Write-Host ""
Write-Host "STEP 5: Initializing database..." -ForegroundColor Yellow

try {
    $response = Invoke-WebRequest -Uri "http://$EC2IP:5000/init-db" -Method Post -TimeoutSec 5 -ErrorAction Stop
    Write-Host "  OK: Database initialized" -ForegroundColor Green
}
catch {
    Write-Host "  WAIT: Trying again..." -ForegroundColor DarkGray
    Start-Sleep -Seconds 3
    try {
        $response = Invoke-WebRequest -Uri "http://$EC2IP:5000/init-db" -Method Post -TimeoutSec 5 -ErrorAction Stop
        Write-Host "  OK: Database initialized" -ForegroundColor Green
    }
    catch {
        Write-Host "  INFO: Database init may be automatic" -ForegroundColor DarkGray
    }
}

Write-Host ""
Write-Host "=========================================" -ForegroundColor Green
Write-Host "DEPLOYMENT COMPLETE!" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Your app is live at: http://$EC2IP:5000" -ForegroundColor Cyan
Write-Host ""
Write-Host "Commands:" -ForegroundColor Yellow
Write-Host "  View logs:  ssh -i '$KeyPath' ec2-user@$EC2IP tail -f ~/app/app.log" -ForegroundColor DarkGray
Write-Host "  Stop app:   ssh -i '$KeyPath' ec2-user@$EC2IP pkill -f 'python backend/run.py'" -ForegroundColor DarkGray
Write-Host "  Re-test:    .\ec2-test.ps1 $EC2IP" -ForegroundColor DarkGray
Write-Host ""
