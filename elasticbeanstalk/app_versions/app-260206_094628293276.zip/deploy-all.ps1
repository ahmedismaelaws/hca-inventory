#!/usr/bin/env powershell
# Master Deployment Script - Does Everything Automatically
# Usage: .\deploy-all.ps1 -KeyPath "C:\path\to\key.pem" -EC2IP "3.226.255.34"
# Or just run it and it will prompt you

param(
    [string]$KeyPath,
    [string]$EC2IP = "3.226.255.34"
)

# If KeyPath not provided, ask for it
if (-not $KeyPath) {
    Write-Host ""
    Write-Host "=========================================" -ForegroundColor Green
    Write-Host "MASTER DEPLOYMENT SCRIPT" -ForegroundColor Green
    Write-Host "=========================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "Enter the full path to your SSH key (.pem file):" -ForegroundColor Cyan
    Write-Host "Example: C:\Users\YourName\Downloads\hca-inventory-key.pem" -ForegroundColor DarkGray
    $KeyPath = Read-Host "Key path"
}

# Validate key file exists
if (-not (Test-Path $KeyPath)) {
    Write-Host ""
    Write-Host "❌ ERROR: Key file not found at: $KeyPath" -ForegroundColor Red
    Write-Host "Please provide the correct path to your .pem key file" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "=========================================" -ForegroundColor Green
Write-Host "AUTOMATIC DEPLOYMENT IN PROGRESS" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Green
Write-Host ""
Write-Host "EC2 IP: $EC2IP" -ForegroundColor Cyan
Write-Host "Key: $KeyPath" -ForegroundColor Cyan
Write-Host ""

# Step 1: Transfer Files
Write-Host "STEP 1: Transferring code files to EC2..." -ForegroundColor Yellow
Write-Host "  Transferring backend/" -ForegroundColor DarkGray

try {
    # Create app directory
    ssh -i "$KeyPath" -o StrictHostKeyChecking=no ec2-user@$EC2IP "mkdir -p ~/app" 2>$null
    
    # Transfer backend
    scp -i "$KeyPath" -o StrictHostKeyChecking=no -r "backend\*" ec2-user@${EC2IP}:~/app/backend/ 2>$null
    Write-Host "  ✓ Backend transferred" -ForegroundColor Green
    
    # Transfer .env
    scp -i "$KeyPath" -o StrictHostKeyChecking=no ".env" ec2-user@${EC2IP}:~/app/.env 2>$null
    Write-Host "  ✓ .env transferred" -ForegroundColor Green
    
    # Transfer setup script
    scp -i "$KeyPath" -o StrictHostKeyChecking=no "ec2-complete-setup.sh" ec2-user@${EC2IP}:~/app/setup.sh 2>$null
    Write-Host "  ✓ Setup script transferred" -ForegroundColor Green
    
} catch {
    Write-Host "  ❌ Transfer failed: $_" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "STEP 2: Running setup on EC2..." -ForegroundColor Yellow

try {
    ssh -i "$KeyPath" -o StrictHostKeyChecking=no ec2-user@$EC2IP "bash ~/app/setup.sh" 2>&1
    Write-Host "  ✓ Setup completed" -ForegroundColor Green
} catch {
    Write-Host "  ❌ Setup failed: $_" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "STEP 3: Starting Flask application..." -ForegroundColor Yellow

try {
    # Start app in background
    ssh -i "$KeyPath" -o StrictHostKeyChecking=no ec2-user@$EC2IP "cd ~/app && source venv/bin/activate && nohup python backend/run.py > ~/app/app.log 2>&1 &" 2>&1
    Write-Host "  ✓ Application started" -ForegroundColor Green
    
    # Wait for app to start
    Write-Host "  Waiting for app to initialize..." -ForegroundColor DarkGray
    Start-Sleep -Seconds 5
    
} catch {
    Write-Host "  ⚠ Warning: Could not start app via SSH: $_" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "STEP 4: Testing deployment..." -ForegroundColor Yellow

# Test endpoints
$tests = @(
    @{ Name = "Health Check"; URL = "http://$EC2IP:5000/health" },
    @{ Name = "Root Endpoint"; URL = "http://$EC2IP:5000/" },
    @{ Name = "API Status"; URL = "http://$EC2IP:5000/api/status" }
)

$allPassed = $true

foreach ($test in $tests) {
    try {
        $response = Invoke-WebRequest -Uri $test.URL -Method Get -TimeoutSec 5 -ErrorAction Stop
        if ($response.StatusCode -eq 200) {
            Write-Host "  ✓ $($test.Name): PASS" -ForegroundColor Green
        } else {
            Write-Host "  ⚠ $($test.Name): Status $($response.StatusCode)" -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host "  ⏳ $($test.Name): App may still be starting..." -ForegroundColor DarkGray
        $allPassed = $false
    }
}

Write-Host ""
Write-Host "STEP 5: Initialize database..." -ForegroundColor Yellow

try {
    $response = Invoke-WebRequest -Uri "http://$EC2IP:5000/init-db" -Method Post -TimeoutSec 5 -ErrorAction Stop
    if ($response.StatusCode -eq 200) {
        Write-Host "  ✓ Database initialized" -ForegroundColor Green
    }
} catch {
    Write-Host "  ⏳ Database initialization: trying again..." -ForegroundColor DarkGray
    Start-Sleep -Seconds 3
    try {
        $response = Invoke-WebRequest -Uri "http://$EC2IP:5000/init-db" -Method Post -TimeoutSec 5 -ErrorAction Stop
        Write-Host "  ✓ Database initialized" -ForegroundColor Green
    } catch {
        Write-Host "  ⚠ Could not initialize database yet - app may still be starting" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "=========================================" -ForegroundColor Green
Write-Host "✅ DEPLOYMENT COMPLETE!" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Your Application is Live!" -ForegroundColor Cyan
Write-Host ""
Write-Host "Access it at:" -ForegroundColor Yellow
Write-Host "  Health:  http://$EC2IP:5000/health" -ForegroundColor Cyan
Write-Host "  API:     http://$EC2IP:5000" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "  1. If tests show 'still starting', wait 10 seconds and run tests again:" -ForegroundColor DarkGray
Write-Host "     .\ec2-test.ps1 $EC2IP" -ForegroundColor DarkGray
Write-Host "  2. To view live logs on EC2:" -ForegroundColor DarkGray
Write-Host "     ssh -i \"$KeyPath\" ec2-user@$EC2IP tail -f ~/app/app.log" -ForegroundColor DarkGray
Write-Host "  3. To stop the app:" -ForegroundColor DarkGray
Write-Host "     ssh -i \"$KeyPath\" ec2-user@$EC2IP pkill -f 'python backend/run.py'" -ForegroundColor DarkGray
Write-Host ""
