# PowerShell script to test deployed EC2 application
# Usage: .\ec2-test.ps1 54.123.45.67

param(
    [Parameter(Mandatory=$true)]
    [string]$EC2_IP,
    
    [Parameter(Mandatory=$false)]
    [int]$PORT = 5000
)

$BaseURL = "http://$EC2_IP:$PORT"

Write-Host ""
Write-Host "=========================================" -ForegroundColor Green
Write-Host "EC2 Application Test" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Target: $BaseURL"
Write-Host ""

# Test 1: Health Check
Write-Host "Test 1: Health Check" -ForegroundColor Cyan
Write-Host "GET $BaseURL/health" -ForegroundColor DarkGray
try {
    $response = Invoke-WebRequest -Uri "$BaseURL/health" -Method Get -TimeoutSec 5 -ErrorAction Stop
    Write-Host "✓ Status: $($response.StatusCode)" -ForegroundColor Green
    Write-Host "✓ Response: $($response.Content)" -ForegroundColor Green
} catch {
    Write-Host "✗ Failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""

# Test 2: Root Endpoint
Write-Host "Test 2: Root Endpoint" -ForegroundColor Cyan
Write-Host "GET $BaseURL/" -ForegroundColor DarkGray
try {
    $response = Invoke-WebRequest -Uri "$BaseURL/" -Method Get -TimeoutSec 5 -ErrorAction Stop
    Write-Host "✓ Status: $($response.StatusCode)" -ForegroundColor Green
    Write-Host "✓ Response: $($response.Content)" -ForegroundColor Green
} catch {
    Write-Host "✗ Failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""

# Test 3: Initialize Database
Write-Host "Test 3: Initialize Database" -ForegroundColor Cyan
Write-Host "POST $BaseURL/init-db" -ForegroundColor DarkGray
try {
    $response = Invoke-WebRequest -Uri "$BaseURL/init-db" -Method Post -TimeoutSec 5 -ErrorAction Stop
    Write-Host "✓ Status: $($response.StatusCode)" -ForegroundColor Green
    Write-Host "✓ Response: $($response.Content)" -ForegroundColor Green
} catch {
    Write-Host "✗ Failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""

# Test 4: API Status
Write-Host "Test 4: API Status (Fallback)" -ForegroundColor Cyan
Write-Host "GET $BaseURL/api/status" -ForegroundColor DarkGray
try {
    $response = Invoke-WebRequest -Uri "$BaseURL/api/status" -Method Get -TimeoutSec 5 -ErrorAction Stop
    Write-Host "✓ Status: $($response.StatusCode)" -ForegroundColor Green
    Write-Host "✓ Response: $($response.Content)" -ForegroundColor Green
} catch {
    Write-Host "✗ Failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "=========================================" -ForegroundColor Green
Write-Host "Testing Complete" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Green
Write-Host ""
