# 🚀 HCA Inventory EC2 Deployment - Complete Package

## What You Have

I've created an **automated deployment package** that handles everything for you.

### Files Created:
1. **EC2_QUICK_START.md** ⭐ START HERE
   - 5-step checklist
   - ~15 minutes to deploy

2. **EC2_AUTOMATED_SETUP.md**
   - Detailed step-by-step guide
   - Troubleshooting section
   - Command reference

3. **ec2-complete-setup.sh**
   - Automated setup script for EC2
   - Installs Python, dependencies, creates env

4. **ec2-transfer.bat**
   - Windows batch script
   - Automatically transfers your code to EC2
   - Usage: `.\ec2-transfer.bat 54.123.45.67 "C:\keys\key.pem"`

5. **ec2-test.ps1**
   - PowerShell test script
   - Validates deployment after setup
   - Usage: `.\ec2-test.ps1 54.123.45.67`

---

## 3-Sentence Summary

1. **Launch EC2** in AWS Console (t3.micro, free tier)
2. **Run script**: `ec2-transfer.bat` + SSH setup + `ec2-complete-setup.sh`
3. **Start app**: SSH in and run `python backend/run.py`

---

## Quickest Path to Deployment

```powershell
# 1. On your work laptop, after EC2 is launched:
cd "C:\Users\KRA2665\AI Inventory"
.\ec2-transfer.bat 54.123.45.67 "C:\keys\hca-inventory-key.pem"

# 2. SSH in (from the batch script output)
ssh -i "C:\keys\hca-inventory-key.pem" ec2-user@54.123.45.67

# 3. Run setup on EC2
bash ~/app/setup.sh

# 4. Start app on EC2
cd ~/app && source venv/bin/activate && cd backend && python run.py

# 5. Test from work laptop (new PowerShell)
.\ec2-test.ps1 54.123.45.67
```

---

## What You Need From AWS

**Just the EC2 Info:**
- Public IPv4 address (e.g., `54.123.45.67`)
- SSH key (.pem file)

**That's it.** Everything else is automated.

---

## Infrastructure Overview

```
Your Work Laptop
    ↓ (SSH via key.pem)
EC2 Instance (t3.micro, free tier)
    ├─ Python 3.10
    ├─ Flask app (backend/)
    ├─ Virtual environment
    └─ .env credentials
        ↓ (DB connection)
        AWS RDS MySQL Database
        └─ hca-inventory-db
```

---

## What Happens When You Deploy

1. **Launch EC2** - t3.micro Amazon Linux 2 (free tier)
2. **Transfer code** - Backend files + .env + setup script
3. **Run setup script** - Installs Python, pip, creates venv, installs deps
4. **Start app** - `python run.py` starts Flask on port 5000
5. **Access app** - `http://54.123.45.67:5000/health`

---

## Cost

- **EC2 t3.micro**: FREE (750 hours/month free tier)
- **RDS MySQL**: Included (already running, shared database)
- **Total**: $0/month (while in free tier)

---

## After Deployment

### Option A: Keep Running on EC2
```bash
# Keep app alive even after SSH exit
nohup python backend/run.py > app.log 2>&1 &

# Share URL: http://54.123.45.67:5000
```

### Option B: Transfer to Personal PC
Follow `TRANSFER_TO_PERSONAL_PC.md` for local development

---

## Support During Deployment

If you encounter issues:

1. **Check EC2_AUTOMATED_SETUP.md** - Troubleshooting section
2. **Look at SSH error output** - Usually very clear
3. **Check security group** - Ports 22, 80, 5000 must be open
4. **Verify .pem key permissions** - `chmod 600 key.pem` on Linux/Mac

---

## Summary of Next Steps

1. ✅ Read **EC2_QUICK_START.md** (the checklist)
2. ✅ Follow the 5 steps
3. ✅ Run the scripts
4. ✅ Your app is live

**Estimated total time: 15 minutes**

---

## All Your Deployment Files

In `c:\Users\KRA2665\AI Inventory\`:
- ✅ `backend/` - Your Flask application
- ✅ `.env` - Database credentials
- ✅ `EC2_QUICK_START.md` - Start here
- ✅ `EC2_AUTOMATED_SETUP.md` - Detailed guide
- ✅ `ec2-complete-setup.sh` - Setup automation
- ✅ `ec2-transfer.bat` - File transfer automation
- ✅ `ec2-test.ps1` - Test automation

---

## You're Ready!

👉 **Next: Open `EC2_QUICK_START.md` and start with Step 1**

No more EB debugging, no more 502 errors. Just simple, direct EC2.
