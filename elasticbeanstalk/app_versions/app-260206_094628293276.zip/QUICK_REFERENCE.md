# ⚡ Quick Reference Guide

## 🚀 Getting Started

### Start Everything
```powershell
cd "c:\Users\KRA2665\AI Inventory"
docker-compose up --build -d
Start-Sleep -Seconds 30
docker-compose exec backend python cli.py --init-db
```

### Stop Everything
```powershell
docker-compose down
```

## 🎯 Access Points

| Service | URL | Purpose |
|---------|-----|---------|
| Frontend | http://localhost:3000 | Web UI |
| Backend API | http://localhost:5000/api | REST API |
| MySQL | localhost:3306 | Database |

## 🔐 Credentials

| Service | Username | Password |
|---------|----------|----------|
| Admin | admin | admin |
| MySQL | aiuser | ai_password |

## 📁 Key Files

| File | Purpose |
|------|---------|
| `.env` | Configuration |
| `docker-compose.yml` | Container setup |
| `backend/requirements.txt` | Python dependencies |
| `frontend/package.json` | Node dependencies |
| `README.md` | Full documentation |

## 🛠️ Common Commands

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f mysql
```

### Database Access
```bash
# MySQL CLI
docker-compose exec mysql mysql -u aiuser -p ai_inventory

# Password: ai_password
```

### Initialize/Train
```bash
# Initialize database
docker-compose exec backend python cli.py --init-db

# Train AI model
docker-compose exec backend python cli.py --train-csv /app/sample_data/sample_devices.csv
```

### Backend Commands
```bash
# Flask shell
docker-compose exec backend flask shell

# Database migrations
docker-compose exec backend flask db upgrade
docker-compose exec backend flask db downgrade
```

## 📊 Features

### Core Functions
- ✅ Add/Edit/Delete devices
- ✅ Search and filter
- ✅ AI category suggestion
- ✅ CSV import
- ✅ User authentication

### Admin Only (After Login)
- ✅ Create devices
- ✅ Modify devices
- ✅ Delete devices
- ✅ Import CSV

## 🧪 Testing

### Test Backend
```bash
cd backend
pytest tests/
```

### Test Frontend
```bash
cd frontend
npm test
```

## 🐛 Quick Troubleshooting

| Issue | Solution |
|-------|----------|
| Can't access localhost | Check `docker-compose ps` |
| Database error | Restart MySQL: `docker-compose restart mysql` |
| API not responding | Check logs: `docker-compose logs backend` |
| Frontend blank | Hard refresh: Ctrl+F5 |
| Login fails | Verify credentials in `.env` |

## 📱 API Quick Reference

```javascript
// Login
POST /api/auth/login
{ username: "admin", password: "admin" }

// List devices
GET /api/devices

// Create device
POST /api/devices
{ name: "...", category: "...", location: "..." }
// Requires token

// Get AI suggestion
POST /api/ai/suggest
{ description: "device description" }

// Get categories
GET /api/categories

// Get statistics
GET /api/stats
```

## 🔄 Deployment Flow

1. **Prepare**: Update `.env` with production values
2. **Build**: `docker-compose build`
3. **Deploy**: `docker-compose -f docker-compose.yml up -d`
4. **Initialize**: `docker-compose exec backend python cli.py --init-db`
5. **Train**: `docker-compose exec backend python cli.py --train-csv data.csv`
6. **Verify**: Test all features

## 📞 Support Resources

| Need | Location |
|------|----------|
| Quick Start | [SETUP_WINDOWS.md](SETUP_WINDOWS.md) |
| Full Docs | [README.md](README.md) |
| API Details | [API_DOCUMENTATION.md](API_DOCUMENTATION.md) |
| Deployment | [DEPLOYMENT.md](DEPLOYMENT.md) |

## ⚙️ Environment Variables

Key variables in `.env`:
```
DB_HOST=mysql              # Database host
DB_PASSWORD=ai_password    # Database password
JWT_SECRET=...            # Auth secret
ADMIN_PASSWORD=admin      # Admin password
REACT_APP_API_URL=http:/localhost:5000/api
```

## 💡 Pro Tips

1. **Backup Data**: Regularly backup MySQL data
2. **Check Logs**: Always check logs first for issues
3. **Train Model**: Train AI model with real data for better suggestions
4. **Monitor Resources**: Watch CPU/memory usage
5. **Use Tags**: Version your Docker images

## 🎓 Learning Paths

### Beginner
1. Start Docker containers
2. Login to web interface
3. Add test device
4. Try AI suggestion

### Intermediate
1. Explore API endpoints
2. Import CSV data
3. Understand database schema
4. Review code structure

### Advanced
1. Customize styling
2. Extend API endpoints
3. Train ML model with data
4. Deploy to production

## 📈 Performance Tips

- **Search**: Index frequently searched fields
- **Pagination**: Use pagination for large datasets
- **Caching**: Frontend caches auth token
- **Database**: Regular cleanup of old records

## 🔒 Security Checklist

- [ ] Change admin password
- [ ] Generate strong JWT secret
- [ ] Update database password
- [ ] Enable HTTPS in production
- [ ] Configure firewall
- [ ] Set up backups

## 📚 Documentation Structure

```
Project/
├── README.md                 # Main documentation
├── SETUP_WINDOWS.md         # Windows setup guide
├── API_DOCUMENTATION.md     # API reference
├── DEPLOYMENT.md            # Production deployment
├── QUICK_REFERENCE.md       # This file
├── docker-compose.yml       # Container setup
└── .env.example            # Environment template
```

## 🎯 Next Actions

1. ✅ Read [SETUP_WINDOWS.md](SETUP_WINDOWS.md) for Windows setup
2. ✅ Start services: `docker-compose up -d`
3. ✅ Train AI model with your data
4. ✅ Import your inventory via CSV
5. ✅ Customize as needed
6. ✅ Deploy to production

---

**Version**: 1.0.0  
**Last Updated**: 2026-02-05  
**Status**: ✅ Production Ready
