#!/usr/bin/env python
"""
Quick diagnostic script to test the deployed application
"""
import requests
import json
import sys

BASE_URL = "http://hca-inventory-prod.eba-ukv5hgme.us-east-1.elasticbeanstalk.com"

def test_endpoint(path, description):
    url = f"{BASE_URL}{path}"
    try:
        print(f"\n📍 Testing: {description}")
        print(f"   URL: {url}")
        response = requests.get(url, timeout=5)
        print(f"   Status: {response.status_code}")
        try:
            data = response.json()
            print(f"   Response: {json.dumps(data, indent=2)}")
        except:
            print(f"   Response: {response.text[:200]}")
        return response.status_code < 500
    except requests.exceptions.ConnectionError:
        print(f"   ❌ Connection failed - App may not be running yet")
        return False
    except Exception as e:
        print(f"   ❌ Error: {str(e)}")
        return False

print("=" * 70)
print("HCA INVENTORY DEPLOYMENT DIAGNOSTIC")
print("=" * 70)

tests = [
    ("/health", "Health Check"),
    ("/", "Root Endpoint"),
    ("/api/status", "API Status (Fallback)"),
]

results = []
for path, desc in tests:
    results.append(test_endpoint(path, desc))

print("\n" + "=" * 70)
if any(results):
    print("✓ App is responding! Status codes received.")
    if results[0]:
        print("✓ Health endpoint working - app is healthy")
    else:
        print("⚠ Health endpoint not responding yet - still warming up?")
else:
    print("❌ App is not responding - still deploying or has crashed")
    print("   Next steps:")
    print("   1. Wait 5-10 more minutes for Docker build to complete")
    print("   2. Check AWS Console → Elastic Beanstalk → Recent Logs")
    print("   3. Look for errors in the Gunicorn startup logs")

print("=" * 70)
