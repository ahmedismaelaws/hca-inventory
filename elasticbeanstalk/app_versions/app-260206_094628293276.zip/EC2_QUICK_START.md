# EC2 Deployment Checklist

## What You Need to Do (5 steps, ~15 minutes total)

### Step 1: Launch EC2 Instance ✓
- [ ] Go to AWS Console (https://console.aws.amazon.com)
- [ ] Go to EC2 → Instances → Launch Instance
- [ ] Select: Amazon Linux 2, t3.micro
- [ ] Create/select SSH key pair (.pem file)
- [ ] Create security group with ports: 22, 80, 5000
- [ ] Launch instance
- [ ] **SAVE** the Public IPv4 address (e.g., 54.123.45.67)
- [ ] **SAVE** the .pem key file location (e.g., C:\keys\hca-inventory-key.pem)

### Step 2: Transfer Files ✓
On your work laptop, in PowerShell:
```powershell
cd "C:\Users\KRA2665\AI Inventory"
.\ec2-transfer.bat 54.123.45.67 "C:\keys\hca-inventory-key.pem"
```
Or manually with `scp` commands in EC2_AUTOMATED_SETUP.md

### Step 3: SSH and Setup ✓
```powershell
ssh -i "C:\keys\hca-inventory-key.pem" ec2-user@54.123.45.67
```
Then on EC2:
```bash
bash ~/app/setup.sh
```

### Step 4: Start Application ✓
On EC2:
```bash
cd ~/app
source venv/bin/activate
cd backend
python run.py
```

### Step 5: Test ✓
On your work laptop, new PowerShell window:
```powershell
curl http://54.123.45.67:5000/health
# Should return: {"status":"healthy"}

curl -X POST http://54.123.45.67:5000/init-db
# Should return: {"status":"success","message":"Database tables initialized"}
```

---

## You Now Have:

✅ **All Files Created:**
- `EC2_AUTOMATED_SETUP.md` - Complete step-by-step guide
- `ec2-complete-setup.sh` - Automated setup script for EC2
- `ec2-transfer.bat` - Automated file transfer script

✅ **Your Code Ready:**
- `backend/` folder with Flask app
- `.env` file with database credentials
- All dependencies in `backend/requirements.txt`

---

## Total Time Estimate:
- AWS Console (launch EC2): 5 minutes
- File transfer: 2 minutes
- Setup script: 3 minutes
- Start app: 1 minute
- Test: 1 minute
- **Total: ~12 minutes**

---

## Support

If you get stuck:
1. Check the specific error in EC2_AUTOMATED_SETUP.md troubleshooting section
2. Look at SSH terminal output for error messages
3. Check that security group allows port 5000

---

**Ready? Start with Step 1!**
