#!/bin/bash
# Complete EC2 Setup - Run this on the EC2 instance after SSH'ing in
# Just copy and paste this entire script at once

set -e  # Exit on error

echo "========================================="
echo "HCA Inventory EC2 Setup Starting"
echo "========================================="

# Update system
echo "Updating system packages..."
sudo yum update -y > /dev/null 2>&1

# Install Python 3.10 and dependencies
echo "Installing Python 3.10 and dependencies..."
sudo yum install -y python3.10 python3.10-devel python3-pip git > /dev/null 2>&1

# Create app directory
echo "Creating app directory..."
mkdir -p ~/app
cd ~/app

# Create virtual environment
echo "Creating Python virtual environment..."
python3.10 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Upgrade pip
echo "Installing dependencies..."
pip install --upgrade pip > /dev/null 2>&1

# Install requirements (assuming backend/requirements.txt was copied)
if [ -f "backend/requirements.txt" ]; then
    pip install -r backend/requirements.txt > /dev/null 2>&1
    echo "✓ Python packages installed"
else
    echo "⚠ backend/requirements.txt not found - skipping pip install"
fi

# Create .env file
echo "Creating environment configuration..."
cat > .env << 'EOF'
DB_HOST=hca-inventory-db.cy38ska2yyb9.us-east-1.rds.amazonaws.com
DB_USER=admin
DB_PASSWORD=20032004Ayoob3
DB_NAME=ai_inventory
DB_PORT=3306
FLASK_ENV=production
JWT_SECRET=your-secret-key-12345
PORT=5000
EOF

echo "========================================="
echo "✓ Setup Complete!"
echo "========================================="
echo ""
echo "To start the application, run:"
echo "  cd ~/app"
echo "  source venv/bin/activate"
echo "  cd backend"
echo "  python run.py"
echo ""
echo "Then access at: http://YOUR_EC2_IP:5000/health"
echo "========================================="
