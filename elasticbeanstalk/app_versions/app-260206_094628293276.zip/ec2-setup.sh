#!/bin/bash
# Simple EC2 Setup Script for HCA Inventory App
# Run this after SSH'ing into a fresh Amazon Linux 2 EC2 instance

# Update system
sudo yum update -y

# Install Python 3.10 and dependencies
sudo yum install -y python3.10 python3.10-devel python3-pip git

# Verify Python
python3.10 --version

# Create app directory
mkdir -p ~/app
cd ~/app

# Clone or copy your project here
# For now, we'll assume files are copied via SCP or git

# Create virtual environment
python3.10 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Install requirements
pip install --upgrade pip
pip install -r backend/requirements.txt

# Create environment file
cat > .env << 'EOF'
DB_HOST=hca-inventory-db.cy38ska2yyb9.us-east-1.rds.amazonaws.com
DB_USER=admin
DB_PASSWORD=20032004Ayoob3
DB_NAME=ai_inventory
DB_PORT=3306
FLASK_ENV=production
JWT_SECRET=your-secret-key-12345
PORT=5000
EOF

# Start the application
cd backend
python run.py

# Note: For production, use a process manager like systemd or supervisord
# Or run in screen/tmux for testing
