@echo off
REM Windows batch script to transfer code to EC2 instance
REM Usage: ec2-transfer.bat <EC2-IP> <path-to-key.pem>
REM Example: ec2-transfer.bat 54.123.45.67 "C:\keys\my-key.pem"

setlocal enabledelayedexpansion

if "%1"=="" (
    echo Usage: ec2-transfer.bat ^<EC2-IP^> ^<path-to-key.pem^>
    echo Example: ec2-transfer.bat 54.123.45.67 "C:\keys\my-key.pem"
    pause
    exit /b 1
)

if "%2"=="" (
    echo Usage: ec2-transfer.bat ^<EC2-IP^> ^<path-to-key.pem^>
    echo Example: ec2-transfer.bat 54.123.45.67 "C:\keys\my-key.pem"
    pause
    exit /b 1
)

set EC2_IP=%1
set KEY_FILE=%2

echo.
echo =========================================
echo EC2 File Transfer
echo =========================================
echo Target IP: %EC2_IP%
echo Key File: %KEY_FILE%
echo.

REM Check if scp is available (part of OpenSSH for Windows)
where scp >nul 2>nul
if %errorlevel% neq 0 (
    echo ERROR: scp not found. Install OpenSSH for Windows:
    echo   Settings ^> Apps ^> Apps and Features ^> Optional Features
    echo   Add "OpenSSH Client"
    pause
    exit /b 1
)

echo Transferring backend files...
scp -i "%KEY_FILE%" -r "backend\*" ec2-user@%EC2_IP%:~/app/backend/ || (
    echo ERROR: Failed to transfer backend files
    pause
    exit /b 1
)

echo Transferring .env file...
scp -i "%KEY_FILE%" ".env" ec2-user@%EC2_IP%:~/app/.env || (
    echo WARNING: Could not transfer .env - you may need to create it manually on EC2
)

echo Transferring setup script...
scp -i "%KEY_FILE%" "ec2-complete-setup.sh" ec2-user@%EC2_IP%:~/app/setup.sh || (
    echo WARNING: Could not transfer setup script
)

echo.
echo =========================================
echo ✓ Transfer Complete!
echo =========================================
echo.
echo Next steps:
echo   1. SSH into EC2: ssh -i "%KEY_FILE%" ec2-user@%EC2_IP%
echo   2. Run setup: bash ~/app/setup.sh
echo   3. Start app: cd ~/app ^& source venv/bin/activate ^& cd backend ^& python run.py
echo.
pause
