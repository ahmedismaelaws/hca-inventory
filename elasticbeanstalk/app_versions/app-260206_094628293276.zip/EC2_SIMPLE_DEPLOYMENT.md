# Deploy to Simple EC2 Instance

## Step 1: Launch EC2 Instance

Go to AWS Console → EC2 → Instances → Launch Instance

**Configuration:**
- **Image**: Amazon Linux 2 (free tier eligible)
- **Instance Type**: t3.micro (free tier)
- **Security Group**: 
  - Allow SSH (port 22) from your IP
  - Allow HTTP (port 80) 
  - Allow port 5000 (Flask app)
- **Key Pair**: Create or select existing
- **Storage**: 8 GB (default fine)

**Launch it** - Note the Public IP (e.g., 54.123.45.67)

---

## Step 2: Connect via SSH

### On Windows (PowerShell):
```powershell
# Convert .pem key if needed (if you only have .ppk from PuTTY)
# Use PuTTYgen to convert to .pem format

# SSH into the instance
ssh -i "C:\path\to\your-key.pem" ec2-user@54.123.45.67
```

### Or use PuTTY:
1. Open PuTTY
2. Host: `54.123.45.67`
3. Auth → Private Key File → Select your .pem/.ppk file
4. Connect

---

## Step 3: Transfer Your Code

From your work laptop, copy the project to the EC2 instance:

```powershell
# From your work laptop PowerShell
scp -i "C:\path\to\your-key.pem" -r "C:\Users\KRA2665\AI Inventory\backend" ec2-user@54.123.45.67:~/app/

scp -i "C:\path\to\your-key.pem" "C:\Users\KRA2665\AI Inventory\.env" ec2-user@54.123.45.67:~/app/.env
```

Or use WinSCP GUI for easier file transfer.

---

## Step 4: Run Setup Script (On EC2)

Once connected via SSH on the EC2 instance:

```bash
# Go to app directory
cd ~/app

# Download and run setup script (or copy-paste commands from ec2-setup.sh)
sudo yum update -y
sudo yum install -y python3.10 python3.10-devel python3-pip

# Create virtual environment
python3.10 -m venv venv
source venv/bin/activate

# Install Python packages
pip install --upgrade pip
pip install -r backend/requirements.txt

# Create .env file with database credentials
cat > .env << 'EOF'
DB_HOST=hca-inventory-db.cy38ska2yyb9.us-east-1.rds.amazonaws.com
DB_USER=admin
DB_PASSWORD=20032004Ayoob3
DB_NAME=ai_inventory
DB_PORT=3306
FLASK_ENV=production
JWT_SECRET=your-secret-key-12345
PORT=5000
EOF
```

---

## Step 5: Start the Application

```bash
# Still on EC2 instance, in ~/app directory with venv activated
cd backend
python run.py
```

You should see output like:
```
2026-02-05 14:30:00 - __main__ - INFO - ============================================================
2026-02-05 14:30:00 - __main__ - INFO - Starting HCA IT Inventory Backend
2026-02-05 14:30:00 - __main__ - INFO - ============================================================
...
 * Running on http://0.0.0.0:5000
```

---

## Step 6: Test the Application

From your work laptop, in a new PowerShell window:

```powershell
# Test health endpoint
curl http://54.123.45.67:5000/health

# Should return: {"status":"healthy"}
```

Or open in browser: `http://54.123.45.67:5000/health`

---

## Step 7 (Optional): Use Process Manager for Production

To keep the app running even after you disconnect SSH, use `tmux`:

```bash
# On EC2 instance
sudo yum install -y tmux

# Create a tmux session
tmux new-session -d -s app

# Send commands to the session
tmux send-keys -t app "cd ~/app && source venv/bin/activate && cd backend && python run.py" Enter

# Later, you can reconnect:
tmux attach-session -t app

# Detach: Ctrl+B then D
```

Or use `nohup`:
```bash
cd ~/app
source venv/bin/activate
nohup python backend/run.py > app.log 2>&1 &

# Check logs:
tail -f app.log
```

---

## Step 8: Point Domain to EC2 (Optional)

If you have a domain, update DNS to point to the EC2 Public IP.

Or create an Elastic IP in AWS so the IP doesn't change on restart.

---

## Step 9: Initialize Database

Once app is running, initialize the database:

```powershell
# From your work laptop
curl -X POST http://54.123.45.67:5000/init-db

# Should return: {"status":"success","message":"Database tables initialized"}
```

---

## Advantages of EC2 over Elastic Beanstalk

✅ **Simpler**: Direct control, easier to debug
✅ **Transparent**: You can see exactly what's happening
✅ **Faster**: No Docker build delays
✅ **Cost**: t3.micro is free tier
✅ **SSH Access**: Full terminal control
✅ **Easy Updates**: Just edit files and restart

---

## API Endpoints Available

Once running:
- `GET  /health` - Health check
- `POST /init-db` - Initialize database
- `GET  /` - Root endpoint
- `POST /api/auth/login` - Login
- `GET  /api/devices` - List devices
- `POST /api/devices` - Create device
- `GET  /api/devices/<id>` - Get device
- `PUT  /api/devices/<id>` - Update device
- `DELETE /api/devices/<id>` - Delete device

---

## Troubleshooting EC2 Issues

### Can't SSH?
- Check Security Group allows inbound port 22 from your IP
- Check key file permissions: `chmod 600 your-key.pem`
- Check instance is running in EC2 console

### Port 5000 not accessible?
- Check Security Group allows port 5000
- Check Flask app is actually running
- Try: `curl http://localhost:5000/health` from the EC2 instance

### Database connection error?
- Check `.env` file has correct credentials
- From EC2: `python3 -c "import pymysql; pymysql.connect(host='hca-inventory-db.cy38ska2yyb9.us-east-1.rds.amazonaws.com', user='admin', password='20032004Ayoob3', database='ai_inventory')"`

### App crashing?
- Check logs: Look at the terminal output
- Check Python syntax: `python -m py_compile backend/app/*.py`
- Check imports: `python -c "from app import create_app"`

---

## Next: Transfer to Personal PC

Once verified on EC2, you can:
1. Keep running on EC2
2. Or transfer code to personal PC following `TRANSFER_TO_PERSONAL_PC.md`
