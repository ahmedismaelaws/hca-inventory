# ☁️ AWS Deployment Guide - HCA IT Inventory

Complete guide to deploy your application to AWS with multiple options.

---

## 🚀 Quick Option Comparison

| Service | Difficulty | Cost | Setup Time | Best For |
|---------|-----------|------|-----------|----------|
| **Elastic Beanstalk** | ⭐ Easy | $ | 10-15 min | Simple deployment |
| **ECS Fargate** | ⭐⭐ Medium | $ | 15-20 min | Production apps |
| **EC2 + RDS** | ⭐⭐⭐ Hard | $$ | 30-45 min | Full control |
| **AppRunner** | ⭐ Easy | $$ | 5-10 min | Quickest option |

---

## 🟢 RECOMMENDED: AWS Elastic Beanstalk (Easiest)

Elastic Beanstalk is perfect for your Docker application and requires minimal configuration.

### Step 1: Prerequisites

```powershell
# Install AWS CLI
choco install awscli -y

# Install EB CLI
pip install awsebcli

# Verify installation
aws --version
eb --version
```

### Step 2: Create AWS Account & Get Credentials

1. Go to https://aws.amazon.com/
2. Create account (or login)
3. Go to IAM → Users → Create user
4. Attach policy: `AdministratorAccess` (for testing) or create custom policy
5. Create Access Key ID and Secret Access Key
6. Download credentials

### Step 3: Configure AWS CLI

```powershell
aws configure
# Enter:
# - AWS Access Key ID
# - AWS Secret Access Key
# - Default region: us-east-1
# - Default output format: json
```

### Step 4: Initialize Elastic Beanstalk

```powershell
cd "c:\Users\KRA2665\AI Inventory"

# Initialize EB application
eb init -p docker hca-inventory --region us-east-1

# Create environment and deploy
eb create hca-inventory-prod --instance-type t3.micro --single
```

### Step 5: Configure Environment Variables

```powershell
# Set environment variables on EB
eb setenv DB_HOST=hca-inventory-db.example.com DB_USER=aiuser DB_PASSWORD=your_secure_password JWT_SECRET=your_secret
```

### Step 6: Access Your Application

```powershell
# Get the URL
eb open

# View logs
eb logs

# SSH into instance (if needed)
eb ssh
```

### Step 7: Scale & Monitor

```powershell
# Scale to 2 instances
eb scale 2

# Monitor
eb status
eb health

# View dashboard
# https://console.aws.amazon.com/elasticbeanstalk
```

---

## 🔵 ALTERNATIVE: AWS ECS Fargate (Production-Grade)

Better for production with more control.

### Step 1: Create RDS Database

```powershell
# Using AWS CLI
aws rds create-db-instance `
  --db-instance-identifier hca-inventory-db `
  --db-instance-class db.t3.micro `
  --engine mysql `
  --master-username admin `
  --master-user-password "YourSecurePassword123!" `
  --allocated-storage 20 `
  --storage-type gp2
```

Or via AWS Console:
1. RDS → Databases → Create database
2. MySQL 8.0
3. db.t3.micro
4. Configure username/password
5. Public access: Yes
6. Create database

### Step 2: Create ECR Repository

```powershell
# Backend repository
aws ecr create-repository --repository-name hca-inventory-backend --region us-east-1

# Frontend repository
aws ecr create-repository --repository-name hca-inventory-frontend --region us-east-1

# Get login token
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin your-account-id.dkr.ecr.us-east-1.amazonaws.com
```

### Step 3: Build and Push Images

```powershell
# Build backend
cd backend
docker build -t hca-inventory-backend:latest .
docker tag hca-inventory-backend:latest your-account-id.dkr.ecr.us-east-1.amazonaws.com/hca-inventory-backend:latest
docker push your-account-id.dkr.ecr.us-east-1.amazonaws.com/hca-inventory-backend:latest

# Build frontend
cd ../frontend
docker build -t hca-inventory-frontend:latest .
docker tag hca-inventory-frontend:latest your-account-id.dkr.ecr.us-east-1.amazonaws.com/hca-inventory-frontend:latest
docker push your-account-id.dkr.ecr.us-east-1.amazonaws.com/hca-inventory-frontend:latest
```

### Step 4: Create ECS Cluster

```powershell
# Create cluster
aws ecs create-cluster --cluster-name hca-inventory-cluster --region us-east-1

# Or via console:
# https://console.aws.amazon.com/ecs
# Clusters → Create cluster → Select Fargate
```

### Step 5: Create Task Definition

Create `task-definition.json`:

```json
{
  "family": "hca-inventory-task",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "256",
  "memory": "512",
  "containerDefinitions": [
    {
      "name": "backend",
      "image": "YOUR-ACCOUNT-ID.dkr.ecr.us-east-1.amazonaws.com/hca-inventory-backend:latest",
      "portMappings": [
        {
          "containerPort": 5000,
          "hostPort": 5000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "DB_HOST",
          "value": "hca-inventory-db.c1234567890.us-east-1.rds.amazonaws.com"
        },
        {
          "name": "DB_USER",
          "value": "admin"
        },
        {
          "name": "DB_PASSWORD",
          "value": "YourPassword123!"
        },
        {
          "name": "DB_NAME",
          "value": "ai_inventory"
        },
        {
          "name": "JWT_SECRET",
          "value": "your-secret-key"
        }
      ]
    },
    {
      "name": "frontend",
      "image": "YOUR-ACCOUNT-ID.dkr.ecr.us-east-1.amazonaws.com/hca-inventory-frontend:latest",
      "portMappings": [
        {
          "containerPort": 3000,
          "hostPort": 3000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "REACT_APP_API_URL",
          "value": "http://YOUR-BACKEND-URL:5000/api"
        }
      ]
    }
  ]
}
```

Register task definition:

```powershell
aws ecs register-task-definition --cli-input-json file://task-definition.json --region us-east-1
```

### Step 6: Create Service

```powershell
aws ecs create-service `
  --cluster hca-inventory-cluster `
  --service-name hca-inventory-service `
  --task-definition hca-inventory-task `
  --desired-count 2 `
  --launch-type FARGATE `
  --network-configuration "awsvpcConfiguration={subnets=[subnet-12345678],securityGroups=[sg-12345678],assignPublicIp=ENABLED}" `
  --region us-east-1
```

---

## 🟡 QUICK: AWS AppRunner (Fastest)

Simplest option - directly from GitHub/repository.

### Step 1: Push to GitHub

```powershell
cd "c:\Users\KRA2665\AI Inventory"
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/yourusername/hca-inventory.git
git push -u origin main
```

### Step 2: Create AppRunner Service

1. Go to AWS AppRunner console
2. Click "Create service"
3. Select "Source code repository"
4. Connect to GitHub
5. Select your repository
6. Configure:
   - Build command: `docker build -t hca-inventory .`
   - Start command: `docker-compose up -d`
7. Set environment variables
8. Deploy

---

## 🟠 ADVANCED: AWS CloudFormation (Infrastructure as Code)

Create `infrastructure.yaml`:

```yaml
AWSTemplateFormatVersion: '2010-09-09'
Description: 'HCA IT Inventory - Infrastructure as Code'

Parameters:
  DBPassword:
    Type: String
    NoEcho: true
    MinLength: 8

Resources:
  # VPC
  VPC:
    Type: AWS::EC2::VPC
    Properties:
      CidrBlock: 10.0.0.0/16
      EnableDnsHostnames: true
      EnableDnsSupport: true

  # Security Group
  SecurityGroup:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupDescription: HCA Inventory Security Group
      VpcId: !Ref VPC
      SecurityGroupIngress:
        - IpProtocol: tcp
          FromPort: 3000
          ToPort: 3000
          CidrIp: 0.0.0.0/0
        - IpProtocol: tcp
          FromPort: 5000
          ToPort: 5000
          CidrIp: 0.0.0.0/0
        - IpProtocol: tcp
          FromPort: 3306
          ToPort: 3306
          CidrIp: 10.0.0.0/16

  # RDS MySQL Database
  Database:
    Type: AWS::RDS::DBInstance
    Properties:
      DBInstanceIdentifier: hca-inventory-db
      DBInstanceClass: db.t3.micro
      Engine: mysql
      EngineVersion: '8.0'
      MasterUsername: admin
      MasterUserPassword: !Ref DBPassword
      AllocatedStorage: 20
      StorageType: gp2
      VPCSecurityGroups:
        - !Ref SecurityGroup

  # Elastic Container Registry (ECR)
  BackendRepository:
    Type: AWS::ECR::Repository
    Properties:
      RepositoryName: hca-inventory-backend

  FrontendRepository:
    Type: AWS::ECR::Repository
    Properties:
      RepositoryName: hca-inventory-frontend

Outputs:
  DatabaseEndpoint:
    Description: RDS Database Endpoint
    Value: !GetAtt Database.Endpoint.Address
  
  BackendRepositoryUri:
    Description: Backend ECR Repository URI
    Value: !GetAtt BackendRepository.RepositoryUri
  
  FrontendRepositoryUri:
    Description: Frontend ECR Repository URI
    Value: !GetAtt FrontendRepository.RepositoryUri
```

Deploy:

```powershell
aws cloudformation create-stack `
  --stack-name hca-inventory-stack `
  --template-body file://infrastructure.yaml `
  --parameters ParameterKey=DBPassword,ParameterValue=YourPassword123!
```

---

## 🎯 STEP-BY-STEP: Full AWS Deployment (Elastic Beanstalk)

This is the easiest complete path.

### 1. Create AWS Account & Setup CLI

```powershell
# Install AWS CLI
choco install awscli

# Configure
aws configure
# Enter credentials from your AWS account
```

### 2. Create Dockerrun.aws.json

Save as `Dockerrun.aws.json` in project root:

```json
{
  "AWSEBDockerrunVersion": 2,
  "containerDefinitions": [
    {
      "name": "backend",
      "image": "hca-inventory-backend:latest",
      "essential": true,
      "memory": 256,
      "portMappings": [
        {
          "containerPort": 5000,
          "hostPort": 5000
        }
      ],
      "environment": [
        {
          "name": "FLASK_ENV",
          "value": "production"
        },
        {
          "name": "DB_HOST",
          "value": "YOUR_RDS_ENDPOINT"
        },
        {
          "name": "DB_USER",
          "value": "admin"
        },
        {
          "name": "DB_PASSWORD",
          "value": "your_password"
        },
        {
          "name": "DB_NAME",
          "value": "ai_inventory"
        },
        {
          "name": "JWT_SECRET",
          "value": "your_jwt_secret"
        }
      ]
    },
    {
      "name": "frontend",
      "image": "hca-inventory-frontend:latest",
      "essential": true,
      "memory": 256,
      "portMappings": [
        {
          "containerPort": 3000,
          "hostPort": 80
        }
      ],
      "environment": [
        {
          "name": "REACT_APP_API_URL",
          "value": "http://YOUR_BACKEND_URL:5000/api"
        }
      ]
    }
  ]
}
```

### 3. Create RDS Database

```powershell
# Via console or CLI
aws rds create-db-instance `
  --db-instance-identifier hca-inventory-db `
  --db-instance-class db.t3.micro `
  --engine mysql `
  --master-username admin `
  --master-user-password "YourPassword123!" `
  --allocated-storage 20
```

Wait for database to be available, then note the endpoint.

### 4. Initialize Elastic Beanstalk

```powershell
cd "c:\Users\KRA2665\AI Inventory"

# Initialize
eb init -p docker hca-inventory --region us-east-1

# Create and deploy
eb create hca-inventory-prod --instance-type t3.micro
```

### 5. Deploy Application

```powershell
# Deploy
eb deploy

# Open in browser
eb open

# View logs
eb logs -f

# Monitor
eb status
```

### 6. Access Your Application

```powershell
# Get the URL
eb open

# Should show: http://hca-inventory-prod.elasticbeanstalk.com
```

---

## 🔑 Key AWS Services to Know

### EC2
- Virtual servers
- Best for: Custom setup, full control
- Cost: $
- Difficulty: Hard

### RDS
- Managed database
- Best for: MySQL, PostgreSQL, etc.
- Cost: $
- Difficulty: Easy

### Elastic Beanstalk
- Managed Docker deployment
- Best for: Quick deployment of containerized apps
- Cost: Same as EC2
- Difficulty: Easy

### ECS + Fargate
- Container orchestration
- Best for: Production, microservices
- Cost: $$$
- Difficulty: Medium

### S3
- Object storage
- Best for: Static files, backups
- Cost: $
- Difficulty: Easy

### CloudFront
- CDN
- Best for: Fast static file delivery
- Cost: $
- Difficulty: Medium

---

## 💰 Cost Estimation

Monthly costs (rough estimate):

```
Elastic Beanstalk (t3.micro):     ~$10-15
RDS MySQL (db.t3.micro):          ~$10-15
Data transfer:                     ~$1-5
---------------------------------------------
Total:                            ~$20-35/month
```

AWS Free Tier includes:
- 750 hours EC2 (t2.micro)
- 750 hours RDS (db.t2.micro)
- 100GB data transfer

---

## 🔒 Security Best Practices

### 1. Use Secrets Manager

```powershell
# Store secrets in AWS Secrets Manager
aws secretsmanager create-secret `
  --name hca-inventory/db-password `
  --secret-string "YourSecurePassword123!"
```

### 2. Use IAM Roles

- Don't hardcode credentials
- Use IAM roles for EC2/ECS instances
- Least privilege principle

### 3. Enable SSL/TLS

```powershell
# Use AWS Certificate Manager
# https://console.aws.amazon.com/acm
```

### 4. VPC Security

- Keep database in private subnet
- Use security groups
- Enable encryption at rest

### 5. Database Backups

```powershell
# Enable automated backups
aws rds modify-db-instance `
  --db-instance-identifier hca-inventory-db `
  --backup-retention-period 30 `
  --apply-immediately
```

---

## 📊 Monitoring & Logging

### CloudWatch

```powershell
# View logs
aws logs describe-log-groups

# View specific logs
aws logs get-log-events --log-group-name /aws/elasticbeanstalk/hca-inventory/var/log/eb-activity.log
```

### Health Dashboard

```powershell
eb health
```

### Auto-scaling

```powershell
# Configure auto-scaling
eb scale 2
```

---

## 🚀 Deployment Workflow

```
Local Development
       ↓
Push to Git
       ↓
AWS Build (CodePipeline optional)
       ↓
Test on Staging
       ↓
Deploy to Production (Elastic Beanstalk)
       ↓
Monitor with CloudWatch
       ↓
Update database backups
```

---

## 📋 Pre-Deployment Checklist

- [ ] AWS account created
- [ ] AWS CLI installed and configured
- [ ] Docker images built
- [ ] Environment variables documented
- [ ] Database credentials secured
- [ ] JWT secret generated
- [ ] SSL certificate (optional but recommended)
- [ ] Backups configured
- [ ] Monitoring configured
- [ ] Security groups configured
- [ ] Database initialized
- [ ] Application tested locally

---

## 🆘 Common Issues

### Connection Timeout
```powershell
# Check security groups
# Ensure MySQL port 3306 is open for application subnet
```

### Database Connection Failed
```powershell
# Verify RDS endpoint
# Check credentials in environment variables
aws rds describe-db-instances
```

### Application Won't Start
```powershell
eb logs -f
# Check logs for errors
```

### Out of Memory
```powershell
# Upgrade instance type
eb scale --instance-type t3.small
```

---

## 🎯 Next Steps

1. **Choose deployment method** (Elastic Beanstalk recommended)
2. **Create AWS account** and configure CLI
3. **Set up RDS database**
4. **Initialize Elastic Beanstalk**
5. **Deploy application**
6. **Configure domain & SSL** (optional)
7. **Set up backups & monitoring**
8. **Scale as needed**

---

## 📚 AWS Resources

- AWS Documentation: https://docs.aws.amazon.com/
- Elastic Beanstalk: https://docs.aws.amazon.com/elasticbeanstalk/
- RDS: https://docs.aws.amazon.com/rds/
- ECS: https://docs.aws.amazon.com/ecs/
- Free Tier: https://aws.amazon.com/free/

---

## ✅ You're Ready!

Your Docker application is already optimized for AWS. Choose your deployment method and follow the steps above.

**Recommended**: Start with Elastic Beanstalk for quickest deployment.

---

**Version**: 1.0.0  
**Date**: February 5, 2026  
**Status**: Production Ready
