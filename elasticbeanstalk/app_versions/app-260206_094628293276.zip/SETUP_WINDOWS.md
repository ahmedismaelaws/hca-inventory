# 🚀 HCA IT Inventory - Windows Setup Guide

## Quick Start (Using Docker)

### 1. Prerequisites
- ✅ Docker Desktop (with Docker Compose)
- ✅ PowerShell (Windows 10/11)

### 2. Download & Extract
```powershell
# Navigate to the project directory
cd "c:\Users\KRA2665\AI Inventory"
```

### 3. Start the Application
```powershell
# Build and start all services
docker-compose up --build -d

# Wait for services to be ready (30-60 seconds)
Start-Sleep -Seconds 30

# Initialize database
docker-compose exec backend python cli.py --init-db

# Train AI model (optional but recommended)
docker-compose exec backend python cli.py --train-csv /app/sample_data/sample_devices.csv
```

### 4. Access the Application
- **Web Interface**: http://localhost:3000
- **API Documentation**: http://localhost:5000/api
- **Login Credentials**: 
  - Username: `admin`
  - Password: `admin`

### 5. Stop the Application
```powershell
docker-compose down
```

---

## Local Development Setup (Without Docker)

### Backend Setup

```powershell
# 1. Navigate to backend
cd backend

# 2. Create virtual environment
python -m venv venv

# 3. Activate virtual environment
.\venv\Scripts\activate

# 4. Install dependencies
pip install -r requirements.txt

# 5. Initialize database
python cli.py --init-db

# 6. Train AI model (optional)
python cli.py --train-csv sample_data/sample_devices.csv

# 7. Run backend
python run.py
# Server starts on http://localhost:5000
```

### Frontend Setup (New PowerShell Window)

```powershell
# 1. Navigate to frontend
cd frontend

# 2. Install dependencies
npm install

# 3. Start development server
npm start
# Frontend starts on http://localhost:3000
```

---

## MySQL Connection with Workbench

1. Open MySQL Workbench
2. Create new connection:
   - **Connection Name**: HCA Inventory
   - **Hostname**: 127.0.0.1
   - **Port**: 3306
   - **Username**: aiuser
   - **Password**: ai_password
3. Click "Test Connection"
4. Click "OK"

Database name: `ai_inventory`

---

## Troubleshooting

### Docker Issues
```powershell
# Check service status
docker-compose ps

# View logs
docker-compose logs -f

# Restart services
docker-compose restart

# Complete reset
docker-compose down -v
docker-compose up --build -d
```

### Database Connection Error
```powershell
# Wait for MySQL to initialize
Start-Sleep -Seconds 30

# Try again
docker-compose exec backend python cli.py --init-db
```

### API Not Responding
```powershell
# Check backend logs
docker-compose logs backend

# Restart backend
docker-compose restart backend
```

### Frontend Shows Blank Page
```powershell
# Clear Docker cache
docker-compose down
docker-compose up --build -d
```

---

## Environment Configuration

The `.env` file contains all configuration. To customize:

```powershell
# Edit environment file
notepad .env
```

Common settings to change:
```
DB_PASSWORD=your_secure_password
JWT_SECRET=your_secret_key
ADMIN_PASSWORD=your_admin_password
```

---

## Useful Commands

```powershell
# View database
docker-compose exec mysql mysql -u aiuser -p ai_inventory
# Enter password: ai_password

# View backend logs
docker-compose logs backend -f

# View frontend logs
docker-compose logs frontend -f

# Execute command in backend
docker-compose exec backend python cli.py --help

# Rebuild containers
docker-compose up --build -d

# Remove all containers and volumes
docker-compose down -v
```

---

## Features to Try

1. **Login**: Use admin / admin
2. **Add Device**: Click "Add New Device"
3. **AI Suggestion**: Type description, click "AI Suggest Category"
4. **Search**: Use search box to filter devices
5. **Edit Device**: Click "Edit" on any device
6. **Delete Device**: Click "Delete" to remove device
7. **Import CSV**: Use backend API or add via UI

---

## Next Steps

- 📚 Read [README.md](README.md) for complete documentation
- 🧠 Train the AI model with your data
- 🔐 Change admin password in `.env`
- 🚀 Deploy to production when ready
- 📊 Monitor logs for issues

---

**Ready? Let's go! 🎉**
