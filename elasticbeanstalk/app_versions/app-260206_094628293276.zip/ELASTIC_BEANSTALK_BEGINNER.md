# 🚀 Beginner's Guide: Deploy to AWS Elastic Beanstalk (Step-by-Step)

This guide is specifically for beginners. Every step is explained clearly.

---

## 📋 Prerequisites Checklist

Before starting, make sure you have:
- ✅ An AWS account (you can create free tier account at aws.amazon.com)
- ✅ Windows 10 or Windows 11
- ✅ Administrator access on your computer
- ✅ Your project folder: `c:\Users\KRA2665\AI Inventory`
- ✅ About 30 minutes of time

---

## 🎯 What is Elastic Beanstalk?

Think of AWS Elastic Beanstalk like this:
- **Your local computer** = Your office
- **AWS Elastic Beanstalk** = Renting office space in a big building
- **You upload your project** = Putting your files in that office
- **AWS manages it** = The building handles utilities, security, cleaning, etc.

You get your website live on the internet without managing servers yourself.

---

## 📝 What is AWS CLI?

AWS CLI = "Command Line Interface" for AWS
- It's a tool that lets you control AWS from PowerShell
- Instead of clicking buttons in the AWS website, you type commands
- Makes deployment much faster

Think of it like:
- **Clicking AWS website buttons** = Using a TV remote
- **AWS CLI commands** = Using a keyboard for faster control

---

## 📝 What is PowerShell?

PowerShell = Windows command terminal (like Command Prompt but more powerful)
- It's already on your Windows computer
- You type commands and the computer follows them
- Similar to "command prompt" but newer

---

## 🟢 STEP 1: Get Your AWS Credentials

### 1.1 Open AWS Console

1. Go to https://aws.amazon.com/
2. Click **"Sign In"** (top right)
3. Sign in with your AWS account
   - If you don't have one, click "Create AWS account"

### 1.2 Create Access Key

1. Once logged in, click your **account name** (top right corner)
2. Click **"Security Credentials"**
3. On the left menu, click **"Users"**
4. Click on your username
5. Scroll to **"Access Keys"** section
6. Click **"Create access key"**
7. Choose **"Command Line Interface (CLI)"**
8. Accept the warning and click **"Next"**
9. Click **"Create access key"**

**IMPORTANT:** You'll see a page with:
- **Access Key ID** (looks like: AKIAIOSFODNN7EXAMPLE)
- **Secret Access Key** (looks like: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY)

**⚠️ SAVE THESE SOMEWHERE SAFE** - You'll need them in the next step.

---

## 🟢 STEP 2: Install AWS CLI

AWS CLI is the tool that connects your computer to AWS.

### 2.1 Open PowerShell

1. Press **Windows Key** on your keyboard
2. Type **"PowerShell"**
3. Right-click on **"Windows PowerShell"**
4. Click **"Run as administrator"**

You should see a blue window with white text. This is PowerShell.

### 2.2 Install AWS CLI

Copy this command and paste it in PowerShell:

```powershell
msiexec.exe /i https://awscli.amazonaws.com/AWSCLIV2.msi
```

Then press **Enter**.

**What will happen:**
1. A window will appear
2. Click **"Next"** through the installer
3. Click **"Install"**
4. Click **"Finish"**

### 2.3 Verify Installation

Close PowerShell completely, then open it again (as administrator).

Copy and paste this command:

```powershell
aws --version
```

Press **Enter**.

**Expected result:** You should see something like:
```
aws-cli/2.13.0 Python/3.11.0 Windows/10.0.19045
```

If you see this, AWS CLI is installed! ✅

---

## 🟢 STEP 3: Configure AWS CLI

Now you'll tell AWS CLI your credentials so it can connect to your account.

In PowerShell (still open), copy and paste:

```powershell
aws configure
```

Press **Enter**.

You'll see prompts like this. Answer each one:

```
AWS Access Key ID [None]: AKIAIOSFODNN7EXAMPLE
```
- Paste your **Access Key ID** (from Step 1.2)
- Press Enter

```
AWS Secret Access Key [None]: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
```
- Paste your **Secret Access Key** (from Step 1.2)
- Press Enter

```
Default region name [None]: us-east-1
```
- Type: **us-east-1** (this is a region where AWS runs servers)
- Press Enter

```
Default output format [None]: json
```
- Type: **json**
- Press Enter

**Done!** ✅ AWS CLI is now configured.

---

## 🟢 STEP 4: Install Elastic Beanstalk CLI (EB CLI)

EB CLI is the tool specifically for deploying to Elastic Beanstalk.

In PowerShell, copy and paste:

```powershell
pip install awsebcli
```

Press **Enter**.

It will install automatically. Wait for it to finish.

### Verify Installation

Copy and paste:

```powershell
eb --version
```

Press **Enter**.

**Expected result:** You should see something like:
```
EB CLI 3.20.0 (Python 3.11.0)
```

If you see this, EB CLI is installed! ✅

---

## 🟢 STEP 5: Navigate to Your Project

In PowerShell, copy and paste:

```powershell
cd "c:\Users\KRA2665\AI Inventory"
```

Press **Enter**.

**What this does:** It tells PowerShell to go to your project folder.

**Verify:** You should see the path change in PowerShell to show:
```
c:\Users\KRA2665\AI Inventory>
```

---

## 🟢 STEP 6: Create RDS Database (MySQL)

Your application needs a database. We'll create one in AWS.

### 6.1 Go to RDS Console

1. Open https://console.aws.amazon.com/rds/
2. Click **"Databases"** (left menu)
3. Click **"Create database"** (orange button)

### 6.2 Configure Database

Fill in these settings:

**Engine Selection:**
- Click **"MySQL"**
- Select **"MySQL 8.0.35"** (or latest 8.0.x)

**Templates:**
- Select **"Free tier"** (to avoid charges)

**DB instance identifier:**
- Type: `hca-inventory-db`

**Master username:**
- Type: `admin`

**Master password:**
- Type a password: `Secure123!@#` (remember this!)
- Copy it somewhere safe

**DB instance class:**
- Keep as **"db.t3.micro"** (free tier)

**Storage:**
- Keep as **"General Purpose (SSD)"**
- **"Allocated storage"**: 20 GB

**Public accessibility:**
- Choose **"Yes"** (so your app can connect)

**Scroll down and click "Create database"**

This will take 5-10 minutes. We'll continue while it's being created.

---

## 🟢 STEP 7: Initialize Elastic Beanstalk

Back in PowerShell (in your project folder), copy and paste:

```powershell
eb init -p docker hca-inventory --region us-east-1
```

Press **Enter**.

**What will happen:**
1. EB CLI will ask questions
2. Answer them like this:

```
Select an application to use: 
```
Press **Enter** (creates new one)

```
Enter Application Name:
```
Type: `hca-inventory` and press **Enter**

```
It detected Docker. Is this correct?
```
Type: `y` and press **Enter**

```
Select a platform version:
```
Press **Enter** (picks default)

After this completes, you should see: ✅ **Initialized EB for application**

---

## 🟢 STEP 8: Create Environment File

Your application needs configuration. Create a `.env` file.

**In PowerShell**, copy and paste (one command):

```powershell
@"
DB_HOST=your-database-endpoint
DB_USER=admin
DB_PASSWORD=Secure123!@#
DB_NAME=ai_inventory
FLASK_ENV=production
JWT_SECRET=your-secret-key-12345
"@ | Out-File -Encoding UTF8 ".env"
```

Press **Enter**.

**Important:** Replace:
- `your-database-endpoint` with your actual RDS endpoint
- `Secure123!@#` with the password you created

To find your database endpoint:
1. Go to https://console.aws.amazon.com/rds/
2. Click **"Databases"** → **"hca-inventory-db"**
3. Scroll down to **"Connectivity & security"**
4. Copy the **"Endpoint"** (looks like: `hca-inventory-db.c1234567890.us-east-1.rds.amazonaws.com`)

---

## 🟢 STEP 9: Create Elastic Beanstalk Environment

Still in PowerShell, copy and paste:

```powershell
eb create hca-inventory-prod --instance-type t3.micro
```

Press **Enter**.

**What will happen:**
1. AWS will create your environment
2. This takes **5-10 minutes**
3. You'll see lots of text (this is normal)
4. Wait for it to finish

**Success message looks like:**
```
Successfully created environment: hca-inventory-prod
```

---

## 🟢 STEP 10: Deploy Your Application

Still in PowerShell, copy and paste:

```powershell
eb deploy
```

Press **Enter**.

**What will happen:**
1. Your code gets uploaded to AWS
2. Docker containers are built
3. The application starts
4. Takes about **5-10 minutes**

**Success message looks like:**
```
Successfully deployed version...
```

---

## 🟢 STEP 11: Initialize Database

Your application is running, but the database needs to be set up.

In PowerShell, copy and paste:

```powershell
eb ssh
```

Press **Enter**.

**What will happen:**
1. You'll connect to the server via SSH
2. You'll see a command prompt like: `ec2-user@...`

Then copy and paste:

```bash
cd /var/app/current && python cli.py --init-db
```

Press **Enter**.

**Expected output:**
```
✅ Database initialized successfully!
```

Then copy and paste:

```bash
exit
```

Press **Enter**. This closes the SSH connection.

---

## 🟢 STEP 12: Get Your Website URL

Still in PowerShell, copy and paste:

```powershell
eb open
```

Press **Enter**.

**What will happen:**
1. Your default browser will open
2. You'll see your website!

**If it shows an error:**
- Wait 1-2 minutes and refresh
- The application is still starting up

---

## ✅ SUCCESS!

Your website is now live on the internet!

### Testing Your Application

1. You should see a login page
2. Login with:
   - Username: `admin`
   - Password: `admin`
3. Try these features:
   - ✅ Add a new device
   - ✅ Search for devices
   - ✅ Edit a device
   - ✅ Delete a device
   - ✅ Use AI suggestion

---

## 🌐 How to Share Your Website

Your website is now live! Share the URL with your boss.

**To get your URL:**

```powershell
eb open
```

The URL will look like:
```
http://hca-inventory-prod.elasticbeanstalk.com
```

---

## 📊 Useful Commands

After deployment, here are helpful commands:

### View Your Website
```powershell
eb open
```

### Check Application Status
```powershell
eb status
```

### View Recent Logs
```powershell
eb logs
```

### Watch Live Logs
```powershell
eb logs -f
```

### SSH into Server (for debugging)
```powershell
eb ssh
```

### Stop the Application (to save money)
```powershell
eb terminate
```

---

## 💰 Cost Information

**Free Tier (First 12 months):**
- EC2 instance (t2.micro): Free ✅
- RDS (db.t3.micro): Free ✅
- Data transfer: Mostly free ✅

**After free tier or if you exceed:**
- Approximately **$20-35/month**

**To avoid charges:**
- Delete database when not using: `eb terminate`
- Use AWS Free Tier monitoring

---

## 🆘 Common Issues & Solutions

### Issue: "Command not found: eb"
**Solution:** Close PowerShell completely and reopen it (as administrator)

### Issue: "Database connection error"
**Solution:** 
1. Check `.env` file has correct database endpoint
2. Wait 5 minutes for RDS to fully initialize
3. Run `eb deploy` again

### Issue: "Website shows blank page"
**Solution:** 
1. Wait 2-3 minutes (application is starting)
2. Press F5 to refresh
3. Run `eb logs` to check for errors

### Issue: "Access Denied" when connecting to database
**Solution:**
1. Verify database credentials in `.env`
2. Check RDS security group allows connections
3. Verify database endpoint is correct

### Issue: "Port 3000 already in use"
**Solution:** This is only for local development. Skip for AWS deployment.

---

## 📱 Making Changes After Deployment

If you want to update your website:

1. Make changes locally in your project folder
2. In PowerShell, run:
```powershell
eb deploy
```

This re-uploads your code and restarts the application.

---

## 🔐 Changing Admin Password (Recommended)

For security, change the admin password.

### In AWS Console:

1. Go to RDS → Databases → hca-inventory-db
2. Click "Modify"
3. Change the Master password
4. Click "Apply immediately"
5. Update `.env` file with new password
6. Run `eb deploy`

---

## 📞 Getting Help

If something goes wrong:

```powershell
# Check status
eb status

# View logs
eb logs -f

# Get detailed help
eb help
eb deploy --help
```

---

## ✨ What You Just Did

Congratulations! You:

1. ✅ Installed AWS CLI tools
2. ✅ Configured AWS credentials
3. ✅ Created a MySQL database
4. ✅ Set up Elastic Beanstalk environment
5. ✅ Deployed your Docker application
6. ✅ Made your website live on the internet

This is **Enterprise-Level Deployment** - the same process big companies use!

---

## 🎉 Next Steps

1. **Test everything** - Make sure all features work
2. **Share with boss** - Show the live website
3. **Monitor** - Use `eb logs` to watch for errors
4. **Scale up** - If needed, run `eb scale 2` for more servers

---

## 📚 Helpful Links

- AWS Dashboard: https://console.aws.amazon.com/
- Elastic Beanstalk Docs: https://docs.aws.amazon.com/elasticbeanstalk/
- AWS CLI Reference: https://docs.aws.amazon.com/cli/

---

**Version:** 1.0.0  
**Last Updated:** February 5, 2026  
**Difficulty Level:** Beginner Friendly ⭐

**You've got this! 🚀**
