# 📚 API Documentation

## Base URL
```
http://localhost:5000/api
```

## Authentication

### Login
Get JWT token for authenticated requests.

**Endpoint:**
```
POST /auth/login
```

**Request:**
```json
{
  "username": "admin",
  "password": "admin"
}
```

**Response (200 OK):**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Error Responses:**
- `400 Bad Request`: Missing credentials
- `401 Unauthorized`: Invalid credentials

**Usage:**
```javascript
// Store token
localStorage.setItem('token', response.data.access_token);

// Use in requests
headers: {
  'Authorization': `Bearer ${token}`
}
```

### Validate Token
Check if token is still valid.

**Endpoint:**
```
GET /auth/validate
Headers: Authorization: Bearer {token}
```

**Response (200 OK):**
```json
{
  "valid": true
}
```

---

## Devices Management

### List Devices
Get all devices with optional filtering and pagination.

**Endpoint:**
```
GET /devices?page=1&per_page=20&search=laptop&category=Laptop
```

**Optional Query Parameters:**
- `page`: Page number (default: 1)
- `per_page`: Items per page (default: 100, max: 100)
- `search`: Search in name, description, location
- `category`: Filter by category

**Response (200 OK):**
```json
{
  "items": [
    {
      "id": 1,
      "name": "Dell XPS 13",
      "description": "Laptop for development",
      "category": "Laptop",
      "location": "Office 101",
      "created_at": "2026-02-05T10:30:00"
    }
  ],
  "total": 150,
  "pages": 8,
  "current_page": 1
}
```

**Example:**
```javascript
// Fetch all laptops
axios.get('/api/devices?category=Laptop')

// Search for specific device
axios.get('/api/devices?search=Dell')

// With pagination
axios.get('/api/devices?page=2&per_page=50')
```

### Get Single Device
Get detailed information about a specific device.

**Endpoint:**
```
GET /devices/{id}
```

**Response (200 OK):**
```json
{
  "id": 1,
  "name": "Dell XPS 13",
  "description": "Laptop for development",
  "category": "Laptop",
  "location": "Office 101",
  "created_at": "2026-02-05T10:30:00"
}
```

**Error Responses:**
- `404 Not Found`: Device not found

**Example:**
```javascript
axios.get('/api/devices/1')
```

### Create Device
Add a new device to inventory (requires authentication).

**Endpoint:**
```
POST /devices
Headers: Authorization: Bearer {token}
```

**Request:**
```json
{
  "name": "Dell XPS 13",
  "description": "Laptop for development",
  "category": "Laptop",
  "location": "Office 101"
}
```

**Response (201 Created):**
```json
{
  "id": 1,
  "name": "Dell XPS 13",
  "description": "Laptop for development",
  "category": "Laptop",
  "location": "Office 101",
  "created_at": "2026-02-05T10:30:00"
}
```

**Error Responses:**
- `400 Bad Request`: Invalid data
- `401 Unauthorized`: Not authenticated
- `409 Conflict`: Data conflict

**Example:**
```javascript
axios.post('/api/devices', {
  name: 'New Laptop',
  category: 'Laptop'
}, {
  headers: { 'Authorization': `Bearer ${token}` }
})
```

### Update Device
Modify an existing device (requires authentication).

**Endpoint:**
```
PUT /devices/{id}
Headers: Authorization: Bearer {token}
```

**Request:**
```json
{
  "name": "Updated Name",
  "category": "Updated Category"
}
```

**Response (200 OK):**
```json
{
  "id": 1,
  "name": "Updated Name",
  ...
}
```

**Error Responses:**
- `400 Bad Request`: Invalid data
- `401 Unauthorized`: Not authenticated
- `404 Not Found`: Device not found

**Example:**
```javascript
axios.put('/api/devices/1', {
  name: 'Updated Name'
}, {
  headers: { 'Authorization': `Bearer ${token}` }
})
```

### Delete Device
Remove a device from inventory (requires authentication).

**Endpoint:**
```
DELETE /devices/{id}
Headers: Authorization: Bearer {token}
```

**Response (200 OK):**
```json
{
  "msg": "Device deleted successfully"
}
```

**Error Responses:**
- `401 Unauthorized`: Not authenticated
- `404 Not Found`: Device not found

**Example:**
```javascript
axios.delete('/api/devices/1', {
  headers: { 'Authorization': `Bearer ${token}` }
})
```

### Import from CSV
Bulk import devices from CSV file (requires authentication).

**Endpoint:**
```
POST /devices/import
Headers: Authorization: Bearer {token}
Content-Type: multipart/form-data
```

**Request:**
```
file: <CSV file>
```

**CSV Format:**
```csv
name,description,category,location
Dell XPS 13,Laptop computer,Laptop,Office 101
HP Printer,Color printer,Printer,Break Room
```

**Response (200 OK):**
```json
{
  "created": 10,
  "skipped": 2
}
```

**Example:**
```javascript
const formData = new FormData();
formData.append('file', fileInput.files[0]);

axios.post('/api/devices/import', formData, {
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'multipart/form-data'
  }
})
```

---

## AI Features

### Get Category Suggestion
Use AI to suggest device category based on description.

**Endpoint:**
```
POST /ai/suggest
```

**Request:**
```json
{
  "description": "Dell XPS 13 laptop with Intel i7 processor"
}
```

**Response (200 OK):**
```json
{
  "suggested_category": "Laptop"
}
```

**Error Responses:**
- `400 Bad Request`: Description too short
- `503 Service Unavailable`: Model not trained

**Example:**
```javascript
axios.post('/api/ai/suggest', {
  description: 'High-end gaming laptop with RTX GPU'
})
```

---

## Utilities

### List Categories
Get all unique device categories.

**Endpoint:**
```
GET /categories
```

**Response (200 OK):**
```json
{
  "categories": [
    "Laptop",
    "Desktop",
    "Printer",
    "Server",
    "Monitor"
  ]
}
```

### Get Statistics
Get inventory statistics.

**Endpoint:**
```
GET /stats
```

**Response (200 OK):**
```json
{
  "total_devices": 150,
  "unique_categories": 8,
  "unique_locations": 25
}
```

---

## Status Codes

| Code | Meaning |
|------|---------|
| 200 | OK - Request succeeded |
| 201 | Created - Resource created successfully |
| 400 | Bad Request - Invalid input |
| 401 | Unauthorized - Authentication required |
| 404 | Not Found - Resource not found |
| 409 | Conflict - Data conflict |
| 500 | Internal Server Error |
| 503 | Service Unavailable - Model not trained |

---

## Error Responses

All errors follow this format:

```json
{
  "msg": "Error description",
  "errors": [
    "Specific error 1",
    "Specific error 2"
  ]
}
```

---

## Rate Limiting

No rate limiting in place. For production deployments, consider implementing:
- Per-IP limits
- Per-user limits
- Burst protection

---

## CORS

CORS is enabled for all origins (`*`). In production, restrict to your domain:

```python
CORS(app, resources={
    r"/api/*": {"origins": "https://yourdomain.com"}
})
```

---

## Examples

### Complete Workflow
```javascript
// 1. Login
const loginRes = await axios.post('http://localhost:5000/api/auth/login', {
  username: 'admin',
  password: 'admin'
});
const token = loginRes.data.access_token;

// 2. Get statistics
const stats = await axios.get('http://localhost:5000/api/stats');
console.log(stats.data);

// 3. Create device
const createRes = await axios.post('http://localhost:5000/api/devices', {
  name: 'New Device',
  category: 'Laptop'
}, {
  headers: { 'Authorization': `Bearer ${token}` }
});

// 4. Get AI suggestion
const suggestionRes = await axios.post('http://localhost:5000/api/ai/suggest', {
  description: 'Dell laptop computer for office use'
});

// 5. List devices
const devicesRes = await axios.get('http://localhost:5000/api/devices?search=Dell');
```

### Error Handling
```javascript
try {
  const response = await axios.post('/api/devices', data, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
} catch (error) {
  if (error.response?.status === 401) {
    // Re-login required
  } else if (error.response?.status === 400) {
    // Validation error
    console.log(error.response.data.errors);
  } else {
    // Other error
    console.log(error.response?.data?.msg || error.message);
  }
}
```

---

## Testing with cURL

```bash
# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin"}'

# List devices
curl http://localhost:5000/api/devices

# Create device
curl -X POST http://localhost:5000/api/devices \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"Test Device","category":"Laptop"}'

# Get suggestion
curl -X POST http://localhost:5000/api/ai/suggest \
  -H "Content-Type: application/json" \
  -d '{"description":"Dell laptop computer"}'
```

---

**Last Updated**: 2026-02-05  
**Version**: 1.0.0
